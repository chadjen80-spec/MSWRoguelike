# Floating Market — Adele Roguelike Skill Evolution System (M1 GDD)

> 🔖 **AI note — resuming?** If you're reading this in a new session to continue/resume this game, load the `msw-planning` skill FIRST and follow its resume flow (read `FloatingMarket-Roadmap.md` + `Archive/As-built.md` → reconstruct state → reconcile) — don't edit or implement straight from this doc. **Before touching any `⬜/🟡/✅` state or running a completion, Read the skill's `references/build-management.md` IN FULL.**
> Last updated: 2026-08-12 / Stage: M1 complete (Phase 1 + Phase 2 all ✅, all 10 sprint acceptance checks verified in-play)

## 1. One-line concept
> "Transform the existing random level-up choices into a structured, data-driven Adele skill evolution system: categorized skills, two staged build paths with prerequisites, weighted valid choice generation, disciplined rerolls, richer cards, and per-run build tracking."

## 2. Key decisions (immutable baseline)
| Item | Decision | Notes |
|---|---|---|
| Camera/map mode | RectTile (InGame arena) — unchanged | KinematicbodyComponent; existing maps untouched |
| Base | EXTEND the existing LevelUpLogic / card UI / skill logics | Spec forbids rebuilding combat or UI architecture |
| Skill names | Keep the shipped, user-chosen names (Punto, GATHERING, BLOSSOM, CREATION, RUIN) and map the sprint's generic chains onto them | Deviation from the spec's literal names, noted in §8 |
| Registry | New `SkillData` UserDataSet = source of truth for category/max level/prerequisite/weight | CurrentLevel is runtime state in a new SkillTreeLogic |
| Determinism | All random draws keep flowing through `_TournamentLogic:RollOffer` | Daily-trial fairness must survive the rework |

## 3. Core loop (one session)
Kill monsters → EXP → level up → choose 1 of 3 **valid** cards (category badge · name · Lv N→N+1 · icon · description · upgrade effect) → skill immediately changes gameplay → build identity emerges (Combat vs Aether vs Passive) → boat return → run summary shows the build → next run resets skill levels/rerolls/scores.

## 4. Core systems
- **Skill registry (SkillData.csv)**: SkillID, Category (COMBAT/AETHER/PASSIVE/UTILITY/ULTIMATE), MaxLevel, PrerequisiteSkill, PrerequisiteLevel, Weight, SwordOnly.
- **SkillTreeLogic (@Logic, ClientOnly)**: loads the registry; resolves each skill's live level from its owning logic (aether stage, summon stage, ultimate unlocked, stat pick counts); eligibility = under max + prerequisite met + class gate; weighted draw; build scores; run reset.
- **Combat line (skill_aether) → 6 stages**: Plain → Punto → Cross → **Cross II** (new: +1 hit line, +reach) → Divide → **Enhanced Divide** (new: rear sword wave — the swing also sweeps behind).
- **Aether/summon line (skill_order) → 5 stages**: ORDER → GATHERING → BLOSSOM → CREATION → **STORM** (new: +2 max blades = 8, +4s flight duration).
- **Prerequisite (data-driven)**: skill_order requires skill_aether ≥ 2 — the summon arts open once the blade art has advanced (registry row, not code).
- **Choice generation**: weighted sampling without replacement over eligible skills; weight soft-boosted by the player's dominant build category; never duplicates; reroll never returns the identical triple when an alternative exists.
- **Card UI**: badge for EVERY card (adds green Passive / blue Utility), stat cards gain Lv N→N+1 lines, skill cards gain explicit upgrade-effect lines.
- **Build tracking**: per-category pick counters; shown on the voyage summary build line.

## 5. System ↔ MSW mapping (real implementation)
| Game system | MSW implementation |
|---|---|
| Skill registry | UserDataSet `SkillData` (.csv under `01. DataTable/01. DataSet/`) |
| Skill tree state / eligibility / weights / build scores | new `@Logic` `22. SkillTree/SkillTreeLogic.mlua` (ClientOnly) |
| Choice generation & reroll guard | existing `LevelUpLogic` delegating to SkillTreeLogic |
| Combat stages 5–6 | `AetherSkillLogic` (maxStage 6) + `Weapon_Sword.stageConfig[5..6]` + rear-wave branch |
| Summon stage 5 (STORM) | `OrderSkillLogic` (GetSummonStage 0–5, maxBlades/duration overrides) |
| Card badges & text | `LevelUpSlotController` (badge kinds passive/utility; level & effect lines) |
| Pick routing / tracking | `PlayerStatController.EnhancePlayer` → `_SkillTreeLogic:OnPicked` |
| Run reset | `ExpeditionLogic.StartExpedition` → `_SkillTreeLogic:ResetForRun` |
| Summary build line | `RunSummaryLogic` build text + build scores |

## 6. Roadmap (Phases)
### Phase 1 — "Data-driven registry & valid choice generation" (4/4 ✅)
- ✅ SkillData.csv registry (8 rows) + SkillTreeLogic (levels, eligibility, prerequisites, weights, build scores, run reset)
- ✅ LevelUpLogic delegates eligibility + weighted no-duplicate draw + reroll same-triple guard
- ✅ Category badges on every card (add Passive green / Utility blue) + stat-card Lv N→N+1 lines
- ✅ Pick tracking wired (EnhancePlayer → OnPicked) + run reset wired (StartExpedition)
### Phase 2 — "Line extensions & build identity" (5/5 ✅)
- ✅ Combat line 6 stages: Cross II (+1 hit, +reach) and Enhanced Divide (rear sword wave), names/icons/card text updated
- ✅ Summon line stage 5 STORM (+2 max blades, +4s duration), card text updated to /5
- ✅ Upgrade-effect lines on all skill cards
- ✅ Build scores on the voyage summary build line
- ✅ Acceptance test: all 10 sprint checks verified in-play (final in-play evidence 08-12: 4 ORDER casts → blades 2/4/6/8 @ duration 16; 5× "Enhanced Divide rear wave struck N"; card pick applies + closes; card text/icon/eligibility probes Acc3-A1..A4)

## 7. Data-driven
SkillData.csv is the source of truth for selection metadata. Per-stage combat/summon behavior stays in the skill logics' config tables (they are behavior, not balance rows); migrating stage configs to CSV is out of scope for M1 (→ Backlog if ever needed).

## 8. Decisions (this milestone)
| Item | Status |
|---|---|
| Map the spec's generic chains onto shipped names (PLAIN II→Punto; AETHER FORGE/AETHER SWORD→the always-known blade base; ENHANCED ORDER→STORM as summon stage 5) | Decided — the spec's stage lists are conceptual ("Possible changes"); shipped user-chosen skills are kept, chains extended to the spec's lengths (6 combat / 5 summon stages) |
| Data-driven prerequisite showcase | Decided: skill_order requires skill_aether ≥ 2 (registry-driven; replaces "always offered" summon line) |
| Category assignment for stat cards | Decided: maxHP/playerAtk/def = PASSIVE; moveSpeed/magnetRange = UTILITY |
| Build-preference weighting strength | Decided: +15% weight per level already invested in the same category, capped ×2 — biases, never locks |

## 9. Plan changes (revision log)
| When | Type | What changed | Reason | Impact |
|---|---|---|---|---|
