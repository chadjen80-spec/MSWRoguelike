# Floating Market — Market & Orders Depth (M6 GDD)

> 🔖 **AI note — resuming?** If you're reading this in a new session to continue/resume this game, load the `msw-planning` skill FIRST and follow its resume flow (read `FloatingMarket-Roadmap.md` + `Archive/As-built.md` → reconstruct state → reconcile) — don't edit or implement straight from this doc. **Before touching any `⬜/🟡/✅` state or running a completion, Read the skill's `references/build-management.md` IN FULL.**
> Last updated: 2026-08-17 / Stage: ✅ COMPLETE — both Phases ✅ (6/6 items), user-verified 08-17; archived

## 1. One-line concept
> "Deepen the market half of the loop: every hunting ground has a daily order (River Fish joins), bigger Weekly orders and one Legendary order give long-run goals with real reputation, the market celebrates growth (fireworks on level-up, festival BGM at Lv.5), and two grounds field a second monster so runs read less uniform."

## 2. Key decisions (immutable baseline)
| Item | Decision | Notes |
|---|---|---|
| Camera/map mode | unchanged — Lobby MapleTile, InGame RectTile | No new maps |
| Base | EXTEND: `OrderData.csv` + `OrderLogic` (server-authoritative, per-user DataStorage) + `OrderBoardUI` rows; `MarketLogic` level events; `MapBGMController`; `MonsterData.csv` reskin rows + `HuntingGroundData.MonsterList` | Same patterns as M1–M5 (data rows + hooks) |
| Order tiers | `OrderData.Tier` column: `daily` (resets by UTC day — existing), `weekly` (resets by ISO week key `yyyy-Www`), `legendary` (one-time per user); still ONE active order at a time; a completed order needs its count in a single delivery (unchanged) | Persistence: existing `OrderDailyDone` + new `OrderWeeklyDone` (`week|ids`) + `OrderLegendaryDone` (`ids`) |
| Board layout | OrderBoardUI keeps 6 row entities; **two pages** — DAILY (6 rows) / WEEKLY & LEGENDARY (3 rows, rest hidden) via a page toggle button (LeaderboardUI `BtnBoard` pattern); rows re-spaced to fit 6 in the current 1000×1060 window; tier tag on each row | No window growth beyond the screen |
| Celebration | Fireworks = `_EffectService:PlayEffect` bursts at fixed Lobby sky points on market level-up + legendary completion (client-local); festival BGM = Lobby BGM swap when market level ≥ 5 (`MapBGMController` reads `_MarketLogic:GetMarketLevel()`) | RUIDs via msw-search (fireworks clip + festival BGM); no new entities |
| Second monsters | Two grounds gain a second roster entry (Shrimp River + Floating Fish Market first): new `MonsterData` reskin rows (crab / another market critter) on the existing slime/snail models, `HuntingGroundData.MonsterList = "A;B"`; the pool already rotates | Drops stay the ground's ingredient (same DropItemID) |
| Fair play | Weekly/legendary rewards are Lobby-side coins/rep only — no tournament interaction | Existing tournament gates untouched |

## 3. Core loop (one session)
Unchanged run loop; in the Lobby the order board now offers a daily per ground plus a Weekly page (bigger hauls, bigger rep) and one Legendary goal; delivering them grows the market faster, and the market answers with fireworks and, at Lv.5, festival music.

## 4. Core systems
- **Orders v2** (`OrderLogic`): rows 6–9 in `OrderData.csv` — daily #6 River Fish (Fish Market); weekly #7 (20 Chicken → 600c +3★), #8 (16 River Fish → 700c +3★); legendary #9 (24 Coconut → 1500c +5★, one-time; accept gated at Market Lv.3, shown LOCKED below). Counts trimmed from the draft (25/20/30) so a single-trip haul stays reachable. Week key = ISO week of UTC now; done maps per tier persisted; accept/complete respect tier done state; board hint text per tier ("resets Mon 00:00 UTC" / "once ever").
- **OrderBoard v2** (`OrderBoardUIController` + `ui/OrderBoardUI.ui`): 6 rows re-spaced (140 px pitch), `Row6` cloned from Row5, page toggle button (DAILY ⇄ WEEKLY & LEGENDARY), tier tag text on each row (colored: daily white / weekly gold / legendary violet), DONE / ACTIVE / dash states as today, rep line + market level unchanged.
- **Market celebration** (`MarketLogic` + `MapBGMController`): `OnReputationSynced` level-up → fireworks (3–5 bursts over ~2 s at Lobby sky anchors) + existing toast/sound; legendary completion → same fireworks; Lobby BGM = festival track when level ≥ 5 (re-evaluated on Lobby enter and on level-up).
- **Second monsters** (data): `Monster_Crab` (Shrimp River, drops Fresh Shrimp) + `Monster_Eel`/market critter (Fish Market, drops River Fish) as reskin rows; MonsterList "Monster_Slime;Monster_Crab", "Monster_Fish;Monster_Eel"; elite/guardian logic unchanged.

## 5. System ↔ MSW mapping
| Game system | MSW implementation |
|---|---|
| Order tiers + resets | `OrderData.csv` (+`Tier` col; rows 6–9) · `OrderLogic` (@Logic, ServerOnly week key via `DateTime.UtcNow`, `EnsureWeeklyFresh`, legendary set) · UserDataStorage keys `OrderWeeklyDone` / `OrderLegendaryDone` in the existing `PersistOrderState` batch (`msw-scripting/references/datastorage.md`) · `SyncOrderState` gains weekly/legendary csv params |
| Board pages | `ui/OrderBoardUI.ui` via UIBuilder (Row6 clone, re-space, `BtnPage`, tier tags) · `OrderBoardUIController` page state (`boardPage`) |
| Fireworks | `_EffectService:PlayEffect(clip, lobbyMap, pos, …)` sequence from `MarketLogic` (ClientOnly), positions = fixed sky anchors in the Lobby; clip via msw-search |
| Festival BGM | `MapBGMController` Lobby branch: `_MarketLogic:GetMarketLevel() >= 5` → festival RUID; `_SoundService:PlayBGM` on level-up while in Lobby |
| Second monsters | `MonsterData.csv` reskin rows (SpriteRUID via msw-search) + `HuntingGroundData.MonsterList`; `MonsterSpawnPool` rotation already in place |

## 6. Roadmap (Phases)
### Phase 1 — "Orders v2" (3/3 ✅)
- ✅ Data + logic: `Tier` column, rows 6–9 (River Fish daily; weekly 20 Chicken / 16 River Fish; legendary 24 Coconut), week key = weeks since Mon 2024-01-01 (`GetWeekKey`, probe `W137`) + `EnsureWeeklyFresh`, legendary once-ever set, keys `OrderWeeklyDone`/`OrderLegendaryDone` in the persist batch, `SyncOrderState` +2 csv params, accept/complete tier rules + legendary Market Lv.3 gate, `MarketLogic:OnLegendaryCompleted` → client toast — probes ✅ (server context) — ⚠️ needs user test: accept a weekly, deliver in one trip, coins + rep + DONE; persistence across restart
- ✅ Board v2: 6 rows (pitch 134) + `Row6` (builder-native TextGUIRenderer texts — Maker injects a black "Text" stub onto new entities that only carry a legacy TextComponent; same fix applied to the M4 slot KeyTexts), `BtnPage` DAILY ⇄ WEEKLY & LEGENDARY (bottom-right, 340×88), `TierText` tags (daily pale / weekly gold / legendary violet), per-tier done hints, LOCKED below Lv.3, info text 680 wide + shorter order lines — probe ✅ (6/3 rows, labels, no stubs) — ⚠️ needs user test: visual fit + page toggle (user screenshot 08-17 drove the layout fix)
- ✅ Acceptance 1–3 in-play — probes ✅ 08-17 + user verdict 08-17 "all good, saved the world" (weekly accepted/delivered, board pages, persistence)
### Phase 2 — "Festival & rosters" (3/3 ✅)
- ✅ Celebration: `MarketLogic.PlayFireworks(n)` (bursts over the player in the Lobby, 0.35 s stagger, clips `61a4a722…`/`e6e81829…` alternating) on market level-up (×5) + legendary completion (×8 via `CelebrateLegendary`); festival BGM `3495faf9…` ("goblin market" event track) at Market Lv.5 — `MapBGMController` Lobby branch on enter + `MarketLogic.ApplyLobbyBGM` on sync/level-up — probes ✅ (fireworks x3/x8 logged in Lobby, BGM flag on at Lv.5 illusion, off after) — ⚠️ needs user test: fireworks look (visible over the market? density?), festival track fits — you'll hear it on the next market level-up or once rep reaches 14
- ✅ Second monsters: `Monster_Crab` (Lorang move clip, HP 28, drops Fresh Shrimp) on Shrimp River, `Monster_Octo` (Seashell Octopus Slime, HP 40, drops River Fish) on the Fish Market — reskin rows on the slime model, rosters `Slime;Crab` / `Fish;Octo` — probe ✅ (rosters + data) — ⚠️ needs user test: both critters spawn and read well in-run, drops correct
- ✅ Acceptance 4–6 in-play — probes ✅ 08-17 + user verdict 08-17 "all good, saved the world" (fireworks + critters; festival BGM at Lv.5 verified by probe illusion, user hears it at rep 14)

## 7. Data-driven
Orders (`OrderData.csv` + `Tier`), monsters (`MonsterData.csv`), rosters (`HuntingGroundData.MonsterList`) — all CSV. Fireworks anchors + festival BGM RUID live as properties on `MarketLogic` / `MapBGMController` (few values; promote to data only if a later milestone adds per-level tracks → roadmap).

## 8. Decisions (this milestone)
| Item | Status |
|---|---|
| Weekly/legendary reward numbers | Decided: W 600c+3★ / 700c+3★, L 1500c+5★ (tune in Phase 1 test) |
| Legendary visibility gate | Decided: shown from Market Lv.3, greyed below |
| Fireworks / festival BGM / second-monster RUIDs | Decided (08-17): fireworks `61a4a722…` + `e6e81829…`; festival BGM `3495faf9…`; Crab = Lorang `164599a7…`, Octo = Seashell Octopus Slime `9e1f28fa…` (eel replaced by octopus — better market fit) — user hand-pick still wins |
| Acceptance checks | 1 six dailies incl. River Fish, one per ground · 2 weekly resets on ISO week, legendary once-ever, both persist · 3 board pages render + accept/deliver a weekly pays coins+rep · 4 fireworks on level-up/legendary · 5 festival BGM at Lv.5 in Lobby · 6 two grounds spawn both roster monsters with correct drops |

> ⚠️ Nothing beyond this milestone lives here — tournament phases, Thief kit, per-ground guardian curves → `Docs/FloatingMarket-Roadmap.md`.

## 9. Plan changes (revision log)
| When | Type | What changed | Reason | Impact |
|---|---|---|---|---|
