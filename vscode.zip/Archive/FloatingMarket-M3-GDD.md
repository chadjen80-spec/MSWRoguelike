# Floating Market — Food × Build Economy Loop (M3 GDD)

> 🔖 **AI note — resuming?** If you're reading this in a new session to continue/resume this game, load the `msw-planning` skill FIRST and follow its resume flow (read `FloatingMarket-Roadmap.md` + `Archive/As-built.md` → reconstruct state → reconcile) — don't edit or implement straight from this doc. **Before touching any `⬜/🟡/✅` state or running a completion, Read the skill's `references/build-management.md` IN FULL.**
> Last updated: 2026-08-15 / Stage: COMPLETE (2026-08-15) — all 3 Phases ✅, 11/11 acceptance

## 1. One-line concept
> "Close the economy loop: Thai food becomes build-strategy fuel — multi-effect meals that hook real combat mechanics (combo gain, elite recovery, skill damage/burn, EXP), upgraded with coins AND ground-linked ingredients, chosen pre-run as TODAY'S MEAL with a build recommendation, visibly growing Pond's market — and a result-screen suite (stats, detected build title, food synergy, next objective) that makes the player think 'one more run.'"

## 2. Key decisions (immutable baseline)
| Item | Decision | Notes |
|---|---|---|
| Camera/map mode | RectTile InGame / MapleTile Lobby — unchanged | No map work beyond Lobby dressing props |
| Base | EXTEND FoodShop/Order/Market/RunSummary systems in place | All four ship and are verified (As-built) |
| Food roster | 6 foods — keep Pad Thai (crit), add Tom Yum Goong; Somtam takes the spec's crit+combo identity | User decision 08-15; no purchased levels deleted |
| Food data model | FoodData.csv gains additive columns (Effect2Name/Effect2Value/SynergyBuild/IngredientItemID/IngredientCount) — old columns untouched | Additive = old readers keep working |
| Balance guardrail | Per-level food effects stay small (1.5–4%/lv); tournament equal-start continues to disable food entirely | Acceptance 3: roguelike picks > permanent stats |
| Upgrade cost | Coins + N× the food's ground-linked ingredient (foods without a natural ingredient stay coins-only) | Connects map ↔ restaurant progression (spec §4) |
| Build-type detection | Highest SkillTreeLogic build-score category → title (COMBAT→BLADECASTER MASTER, AETHER→AETHER MASTER, COMBO→RUIN MASTER, else FREESTYLE) + top skill lines | Reuses M1/M2 tracking, no new state |

## 3. Core loop (one session)
Pick TODAY'S MEAL (see active food + recommended build) → run a ground → ingredients drop → boat home → Pond orders consume ingredients → coins + reputation → market visibly grows → upgrade food (coins + ingredients) → result screen names your build, shows the food's contribution, and points at the next objective → next run.

## 4. Core systems
- **Multi-effect foods (6)**: Somtam (crit +1.5%/lv + combo gain +4%/lv → COMBO), Thai Tea (CDR −4%/lv → AETHER, unchanged), Chicken Rice (maxHP +10/lv + elite-kill heal 2% maxHP/lv → SURVIVAL), Tom Yum Goong (skill damage +2%/lv + burn DoT on signature hits at Lv3+ → COMBAT, new), Pad Thai (crit +3%/lv, unchanged), Mango Sticky Rice (hpRegen +1/lv + EXP gain +2%/lv → FAST LEVEL).
- **Combat hooks**: food effect aggregator in FoodShopLogic (`GetFoodEffect(name)`); consumers — GameLogic (combo gain %), MonsterController elite death (heal), SignatureSkillLogic (skill dmg % + burn ticks), PlayerStatController EXP intake (EXP %).
- **Ingredient-gated upgrades**: FoodShop purchase checks coins AND ingredient stock (Chicken Rice⇐Chicken, Tom Yum⇐Shrimp, Mango Sticky Rice⇐Coconut, Somtam⇐Egg; Thai Tea/Pad Thai coins-only); UI shows the ingredient cost line.
- **TODAY'S MEAL**: MapSelect prep line becomes a meal panel — active food, its effects, recommended build tag (never forced).
- **Visible market growth**: MarketDressing tiers extended — more customer NPCs/tables/boats/decorations per market level.
- **Result suite**: EXPEDITION COMPLETE screen v2 (ground, clear time, kills, max combo, elites, boss, per-item ingredient breakdown, coins, rep gained); build title + top lines; food synergy card (food effects + RUIN casts this run); next-run hook (locked ground rep progress OR missing recipe ingredients).

## 5. System ↔ MSW mapping (real implementation)
| Game system | MSW implementation |
|---|---|
| Food data v2 | FoodData.csv additive columns (dataset) |
| Effect aggregation | `FoodShopLogic.GetFoodEffect` (existing @Logic, ClientOnly) |
| Combo gain hook | `GameLogic.AddCombo` gain multiplier (stacks with COMBO MASTERY) |
| Elite recovery hook | `MonsterController.GetDamage` elite-death branch → heal via PlayerStatController |
| Skill dmg / burn hook | `SignatureSkillLogic` damage calc + timer-tick burn on struck monsters |
| EXP gain hook | player EXP intake path (PlayerStatController / EXP item controller) |
| Upgrade gating + costs | `FoodShopLogic.RequestPurchase` + `FoodShopUIController` cost lines + ItemDataLogic stock |
| TODAY'S MEAL | `MapSelectUIController.RefreshPrepLine` → meal panel |
| Market visual tiers | `MarketDressingComponent` (Lobby) tier props |
| Run stats + result suite | `RunSummaryLogic` + `RunSummaryUIController` + per-run ingredient tally in `ExpeditionLogic.AddIngredient` |
| Build title | `SkillTreeLogic` build scores → title mapping |

## 6. Roadmap (Phases)
### Phase 1 — "Food × Combat" (4/4 ✅)
- ✅ FoodData v2: 6 rows with Effect2/Synergy/Ingredient columns (Tom Yum Goong added; Somtam crit+combo identity w/ level clamp; existing levels preserved)
- ✅ Combat hooks live: combo gain % (epsilon-floor carry fix), elite-kill heal (cap 20%), skill damage % + Lv3+ burn ticks, EXP gain % — all through GetFoodEffect (tournament gate → 0)
- ✅ Ingredient-gated upgrades: NEW pantry (delivered goods bank server-side, DataStorage) + cost check before coins + FoodShopUI Row6 + recipe/stock lines
- ✅ Acceptance 1–4: all probes passed 08-15 + user loop verdict ("Food loop works"); world saved
### Phase 2 — "Pond loop & visible market" (4/4 ✅)
- ✅ TODAY'S MEAL pre-run panel with build recommendation (MapSelect prep line v2: foods w/ levels + "Recommended: X BUILD" from the highest-level synergy food)
- ✅ Order loop audit end-to-end (probe 08-15: order 1 accepted → 8 Chicken → +120 coins → rep 3→4 → NPC mood re-applied)
- ✅ Market dressing tier extension: +8 Lobby props (L2 customer; L3 table+customer; L4 boat+lantern; L5 2 customers+boat), MarketDeco_L<n> convention
- ✅ Acceptance 5–6 in-play (user verdict 08-15 "all good" — incl. the mid-phase additions: Esc-close, boss HP bar, tracker collapse)
### Phase 3 — "Result suite & the next-run hook" (5/5 ✅)
- ✅ Per-run ingredient tally + VOYAGE SUMMARY screen v2 (full §7 stat block; reputation shown as now/next tier)
- ✅ Build-type detection title + top skill lines on the summary
- ✅ Food synergy card (active food effects + signature cast count)
- ✅ Next-run hook (locked-ground market-level progress OR missing recipe ingredients)
- ✅ Acceptance 7–11 in-play incl. permanent-vs-run-scoped reset check (probes 08-15 + user verdict "all good"; world saved)

## 7. Data-driven
FoodData.csv remains the source of truth for all food values (effects, costs, ingredients, synergy tags); no food constants in code. Order/market values stay in OrderData.csv. Burn tick constants live in SignatureSkillLogic config (2 values — under the data-driven threshold).

## 8. Decisions (this milestone)
| Item | Status |
|---|---|
| Burn design | Decided: Tom Yum Lv3+ — signature hits apply 3 ticks × 5% of the hit over 3s (client DoT timer) |
| Ingredient mapping | Decided: ChickenRice⇐Chicken(3), TomYum⇐Shrimp(4), MangoStickyRice⇐Coconut(5), Somtam⇐River Fish(7) — no Egg item exists; som tam pla ra style; ThaiTea/PadThai coins-only |
| Pantry (new) | Decided: no persistent ingredient stock existed (orders use per-trip counts) — delivered ingredients now ALSO bank into a per-user "Pantry" (DataStorage) that recipes consume; coins payout unchanged |
| Build titles | Decided: COMBAT→BLADECASTER MASTER, AETHER→AETHER MASTER, COMBO→RUIN MASTER, tie/none→MARKET FREESTYLER |
| Elite-heal cap | Pending → locked in Phase 1 feel pass (start 2% maxHP × lv, cap 20%) |

## 9. Plan changes (revision log)
| When | Type | What changed | Reason | Impact |
|---|---|---|---|---|
| 2026-08-15 | Add | Esc closes any NPC-opened window (MapSelect/FoodShop/OrderBoard/ItemTable/Inventory/Legacy/Leaderboard) — `UIManageLogic.CloseNpcWindows` on the existing global key listener, gated per-window on open state | User UX request mid-Phase 2 | Implemented immediately; verified with the Phase 2 user test |
| 2026-08-15 | Add | Boss HP bar: top-screen red bar ("CORRUPTED GUARDIAN") in InGameUI — `BossBar` group (builder-built, UUID-bound), `InGameUIController.Show/Hide/RefreshBossBar` (fill = currentHP/bossMaxHP per frame, self-hides on death/despawn/run end), shown from `MonsterController.SetBoss`, dropped on boss death | User UX request mid-Phase 2 | Implemented immediately; verified with the Phase 2 user test (next guardian fight) |
| 2026-08-15 | Add | Collapsible expedition tracker: "-" button on TrackerPanel hides it, root-level SHOW TRACKER tab re-opens it (`InGameUIController.SetTrackerCollapsed/ToggleTracker`, ButtonClickEvent handlers, click SFX) | User UX request mid-Phase 2 | Implemented immediately; verified with the Phase 2 user test |
| 2026-08-15 | Change | Mage class identity → **Battle Mage** (identity swap only, kit mechanics unchanged): select-screen name/description + Death-reaper portrait clip, weapon strike reskinned to Finishing Blow hit burst + Death hit SFX, skill-bar icon → Finishing Blow, signature METEOR → DARK GENESIS (skill/3212.img/32121004 effect + icon), Legacy tree "Arcane Legacy / the Arch Mage" → "Dark Legacy / the Battle Mage". IDs (`Character_Mage`, `Weapon_Thunder`, `UI_Mage`) kept for save/data compatibility | User request mid-Phase 2; full Battle Mage kit deferred (user chose identity swap) | Immediate; user verdict 08-15 "Battle Mage feels good", world saved. Follow-up: aura strike now lands IN FRONT of the player (`Weapon_Thunder` uses `LookDirectionX`, `ForwardGap` 0.3, effect mirrored) instead of a random ±1 spot. Full kit is a future-milestone candidate (Roadmap Backlog) |
| 2026-08-15 | Modify | Result screen "rep gained this run" → "Reputation: N (title) — next tier M" (rep only grows at Pond delivery, after the boat-return summary); non-Adele classes get their class name as build title | Phase 3 planning reconcile | Phase 3 T2/T3 scope; acceptance 7/8 read accordingly |
| 2026-08-15 | Incident | Maker script-DB break after the Battle Mage batch: Check In quarantined 27 nested scripts (`Mislocated/`), DB dropped them + stripped every `.ui`/`Lobby.map` script component; every Maker sync (Play/Export/Import) then mirrored DB→disk and deleted disk-only files. Recovered by re-adding the 29 scripts with FRESH codeblock IDs (DB held the old IDs as tombstones) and restoring entity script components from the 18:17 `.mod` release export via `restore_script_comps.cjs`. All "[X] ready" logs + zero errors afterwards; world saved | Tooling failure, not design | Rule: back up `RootDesk/ui/map` before every Check In; read the Local Changes list for Mislocated/Delete rows; a fresh `.mod` export is the best entity-payload backup |
