# Floating Market — Combo → RUIN Strategic Resource System (M2 GDD)

> 🔖 **AI note — resuming?** If you're reading this in a new session to continue/resume this game, load the `msw-planning` skill FIRST and follow its resume flow (read `FloatingMarket-Roadmap.md` + `Archive/As-built.md` → reconstruct state → reconcile) — don't edit or implement straight from this doc. **Before touching any `⬜/🟡/✅` state or running a completion, Read the skill's `references/build-management.md` IN FULL.**
> Last updated: 2026-08-15 / Stage: M2 complete (Phases 1–3 all ✅, all 11 sprint acceptance checks verified — checks 1–9, 11 in-play with log evidence; check 10 user-verified across all three builds)

## 1. One-line concept
> "Extend the existing combo gauge into Adele's strategic ultimate resource: combo builds to 100 with milestone feedback, RUIN becomes a player-timed, combo-consuming signature that shines against a new 3-phase guardian whose add-wave phase is a deliberate combo opportunity — creating a third (COMBO/RUIN) build path beside Combat and Aether."

## 2. Key decisions (immutable baseline)
| Item | Decision | Notes |
|---|---|---|
| Camera/map mode | RectTile (InGame arena) — unchanged | KinematicbodyComponent; existing maps untouched |
| Base | EXTEND the existing combo system (SignatureSkillLogic) — spec forbids replacing it | RUIN stays the level-up-card ultimate; only its resource economy changes |
| RUIN threshold | Combo ≥ 100 arms RUIN READY (was 20); **no auto-cast** — player presses Q when they choose | Strategic timing is the sprint's core |
| RUIN cost | Casting consumes 100 combo (combo counter −100, gauge restarts) | "Consume the required Combo resource" |
| Combo milestones | 25/50/75 pips + 100 = RUIN READY banner + sound + lit skill-bar icon | Strong visual+audio feedback per spec |
| New category | `COMBO` joins the registry categories; the 6 new upgrades live there so build tracking shows a COMBO build | SkillData.csv + SkillTreeLogic category order |
| Boss | Deepen the existing quota guardian into 3 phases (direct → adds → vulnerability) — not a new monster from scratch | Reuses MonsterSpawnPool.SpawnGuardianBoss + MonsterController |
| Elites / mission-complete flow | Already shipped (corrupted elites, quota→guardian→boat with pier message) — M2 verifies/extends, does not rebuild | As-built rows: Elite Monsters, Boss Encounters, Expedition loop |

## 3. Core loop (one session)
Kill monsters → combo climbs (25/50/75 feedback) → 100 → RUIN READY (icon lit, banner) → player HOLDS or SPENDS → elite appears: spend now for the drop, or save? → quota met → 3-phase guardian → adds wave = combo farm → vulnerability window → RUIN for massive payoff → MISSION COMPLETE → boat at the pier → summary shows the COMBO build line.

## 4. Core systems
- **Combo resource**: existing counter feeds a 0–100 gauge; milestone feedback at 25/50/75; at 100 RUIN READY state (persistent until spent; combo above 100 still counts for summary max-combo).
- **RUIN economy**: locked below 100; Q at ≥100 casts (existing animation/AoE, damage retuned to feel signature-grade), consumes 100, returns to building.
- **Combo build path (6 new SkillData rows, category COMBO)**: COMBO MASTERY (combo gain +20%/lv), RELENTLESS (combo-keep duration +30%/lv), AETHER FLOW (blade hits generate +1 combo), RUIN MASTERY (RUIN damage +20%/lv), ENHANCED RUIN (RUIN area +25%/lv), FINAL RUIN (aftershock attack after RUIN, 1 lv).
- **Elite decision**: elites (existing) tuned so RUIN one-shots them — the spend-or-save question is real.
- **3-phase guardian**: P1 direct attack patterns → P2 (~66% HP) summons add waves (combo fodder) → P3 (~33% HP) vulnerability state (damage taken ×2, visual tell) — RUIN in P3 is the intended payoff; all three builds must clear it (needs user playtests per build).
- **Mission complete**: existing flow (guardian down → "Return boat is waiting at the pier!" + status line, no teleport) — verified, message casing aligned to spec.

## 5. System ↔ MSW mapping (real implementation)
| Game system | MSW implementation |
|---|---|
| Combo gauge & milestones | `SignatureSkillLogic` (threshold/consume/ready state) + combo HUD in `ui/InGameUI.ui` (existing ultimate-READY element, extended) |
| RUIN READY feedback | `SkillBarUIController` (icon lit state) + `_UIToast` + `_SoundService` cue |
| Combo upgrades | SkillData.csv +6 rows (category COMBO) + EnhanceData rows/icons + hooks in `SignatureSkillLogic` / `Weapon_Sword` / `OrderSwordComponent` |
| Build tracking | `SkillTreeLogic` (COMBO in category order) + `RunSummaryLogic` Build line (automatic) |
| Boss phases | `MonsterSpawnPool.SpawnGuardianBoss` + guardian `MonsterController` phase state (HP-threshold driven) + add-wave spawns via the pool |
| Elite tuning | existing elite path in `MonsterSpawnPool` / `ExpeditionLogic.RequestEliteBounty` |
| Mission complete → boat | `ExpeditionLogic.OnBossDefeated` (existing; message polish) |

## 6. Roadmap (Phases)
### Phase 1 — "Combo resource & RUIN economy" (4/4 ✅)
- ✅ Combo → 100 threshold: gauge, 25/50/75 milestone feedback (HUD + sound), RUIN READY at 100 (banner + lit icon + sound)
- ✅ RUIN gating & consumption: locked < 100 (toast), manual Q cast at ≥ 100, −100 combo on cast, signature-grade damage/feel pass (READY banks through combo decay; overflow carries; ×8 multiplier confirmed by feel)
- ✅ In-play verification of acceptance 1–5 (all probe checks + user feel verdict 08-12)
- ✅ STORM active cast: full-flight ORDER button (STORM icon) → 14s blade vortex, periodic multi-line AoE, 3s looping cast visual (added by revision, see §9; user verdict "feels good")
### Phase 2 — "Combo/RUIN build path" (3/3 ✅)
- ✅ 6 new COMBO-category skills in SkillData/EnhanceData with card icons + effect lines (icons are placeholders from existing RUIDs; teal Combo Skill badge; data-driven prereqs verified)
- ✅ Upgrade hooks: combo gain ×(1+0.2L) w/ fractional carry, combo window ×(1+0.3L), blade-hit combo, RUIN damage ×(1+0.2L) / area ×(1+0.25L), FINAL RUIN 0.6s echo @50%
- ✅ COMBO category in SkillTreeLogic order + build summary; all acceptance-6 probes passed 08-12 + user build-feel verdict ("Combo build feels good")
### Phase 3 — "Elite decision & 3-phase guardian" (4/4 ✅)
- ✅ Elite tuning: audit decided no retune (elite ×5 HP vs RUIN atk×8×mods — spend-or-save stays live; §8)
- ✅ Guardian phases: P1 patterns → P2 add waves (combo fodder, +8s repeats) → P3 vulnerability (stagger tint, damage ×2) — in-play phase logs 08-15
- ✅ Mission-complete flow: MISSION COMPLETE toast + RETURN BOAT IS WAITING AT THE PIER status, boat enabled, no teleport — in-play
- ✅ Acceptance 7–11: 7/8/9/11 evidenced in-play; check 10 user-verified 08-15 — all three builds (Combat / Aether / Combo) cleared the guardian

## 7. Data-driven
Combo upgrade magnitudes live in SkillData.csv (Weight/MaxLevel) + EnhanceData rows like all M1 skills. Boss phase thresholds (66%/33%, ×2 vulnerability) stay as guardian config values in code for M2; migrate to a BossData dataset only if a second boss ships (→ roadmap Backlog).

## 8. Decisions (this milestone)
| Item | Status |
|---|---|
| Combo above 100 while READY: keep counting (summary max-combo) but gauge caps at 100 | Decided |
| RUIN base damage multiplier | Decided: ×8 (unchanged) — confirmed by Phase 1 feel pass |
| Elite one-shot rule | Decided: no retune — elite HP ×5 vs RUIN atk×8×mods means RUIN clears elites once atk/mastery grows modestly; the spend-or-save question stays live early-run |
| Boss phase thresholds 66% / 33% | Decided (tunable constants) |

## 9. Plan changes (revision log)
| When | Type | What changed | Reason | Impact |
|---|---|---|---|---|
| 2026-08-12 | Add | STORM becomes an ACTIVE skill: at full flight (4 ORDER casts / 8 blades) the shared ORDER button — showing STORM's own icon — recalls the blades into a wild 14s current around Adele with periodic multi-line AoE pulses (user-supplied RUIDs for anim/hit/sounds/icon). Passive part (+2 blades, 16s flight) stays. | User request mid-Phase 1 | New task T5 in Phase 1 (both docs); summon-line card text updated |
| 2026-08-15 | Remove | Enhanced Divide's rear sword wave (M1 stage-6 extra): the stage≥6 rear-box branch deleted from Weapon_Sword.RequestAttack; stage 6 keeps its front sweep, ×1.75 damage, +1.4 reach; card effect line now "Damage +15% / Reach +0.2" | User request — keep only the front slash | Code removed + AetherSkillLogic stageCardEffects[6] + As-built row updated; M1 archived GDD left as history |
