# Floating Market — Release Polish & Re-release (M5 GDD)

> 🔖 **AI note — resuming?** If you're reading this in a new session to continue/resume this game, load the `msw-planning` skill FIRST and follow its resume flow (read `FloatingMarket-Roadmap.md` + `Archive/As-built.md` → reconstruct state → reconcile) — don't edit or implement straight from this doc. **Before touching any `⬜/🟡/✅` state or running a completion, Read the skill's `references/build-management.md` IN FULL.**
> Last updated: 2026-08-17 / Stage: ✅ COMPLETE — both Phases ✅ (8/8 items), world re-released 08-17; archived

## 1. One-line concept
> "Take the M1–M4 world (Adele + Battle Mage roguelite, market economy, endless/daily) from 'feature-complete' to 'released': real card art for the six COMBO skills, a guardian whose HP scales with the ground's tier and the player's power, an on-device pass on both classes with the fixes it surfaces, and a fresh world release replacing the pre-Battle-Mage build."

## 2. Key decisions (immutable baseline)
| Item | Decision | Notes |
|---|---|---|
| Camera/map mode | unchanged — RectTile InGame (Kinematicbody) / MapleTile Lobby+Title | No new maps, no new classes |
| Base | POLISH ONLY: no new systems; every task edits an existing file or data row | New scripts only if a fix demands one |
| Card art | Six COMBO rows get their own icons: real MapleStory skill icons found via `msw-search` (Adele/Battle Mage packs); user may hand-pick RUIDs — respected as final | Genesis trio keeps the DARK GENESIS icon by design (class-signature art) |
| Guardian scaling | HP multiplier = data column `BossHPMult` per hunting ground (tier proxy = market-level gating order) × a player-power factor from the run's level; numbers live in data, not code | Elite/miniboss/golden multipliers unchanged |
| Device pass | User runs PC + mobile on BOTH classes; findings become fix tasks in Phase 2 (revision flow) | AI cannot verify device feel — those items end `🟡 needs user test` |
| Release | User re-releases from Maker (AI cannot publish); "released" = the published world boots and the last release timestamp is later than 2026-08-15 18:17 | Keep the pre-release `.mod` export as the entity-payload backup |

## 3. Core loop (one session)
Unchanged: pick a class → market prep → hunting ground → level-up cards → guardian → boat → delivery / orders / food → repeat. This milestone changes how it *looks and scales*, not what it is.

## 4. Core systems (touched)
- **COMBO card art**: `EnhanceData.csv` IconID for `comboMastery` / `relentless` / `aetherFlow` / `ruinMastery` / `enhancedRuin` / `finalRuin` → six distinct icons that read as "combo / streak / flow / ruin" at 72 px on the card and 32 px in any future skill list.
- **Guardian scaling**: `MonsterController.SetBoss` reads `HuntingGroundData.BossHPMult` (default 25) via `HuntingGroundLogic` and multiplies by `1 + playerLevel × k` (k tuned so a Lv.1 Chicken Farm guardian stays ~today's 500 HP and a late-run Fish Market guardian is a real fight); the boss bar and phase thresholds follow `bossMaxHP` automatically.
- **Device pass**: checklist per class — movement/joystick, every bar slot tap (ORDER/GATHERING/BLOSSOM/Q; Aura/Teleport/Death), card taps, tracker collapse, boss bar, summary Esc/close, mobile-only hidden bar start.
- **Release**: world save → user Release → boot the published world once (Title → Lobby → one short run) → date check.

## 5. System ↔ MSW mapping
| Game system | MSW implementation |
|---|---|
| Card art | `EnhanceData.csv` (dataset row edits) + `msw-search` for RUIDs; verify via `_DataService:GetTable("EnhanceData")` probe + a card render |
| Guardian scaling | `HuntingGroundData.csv` new column `BossHPMult`; `HuntingGroundLogic` accessor; `MonsterController.SetBoss` formula; `PlayerStatController` level read |
| Device pass | user-run on Maker mobile preview / device; fixes via existing controllers (`SkillBarUIController`, `InGameUIController`, `MobileJumpButton`, `.ui` via UIBuilder) |
| Release | Maker Release dialog (user); `Environment:IsPublishedPlay()` not needed — verify by playing the published world |

## 6. Roadmap (Phases)
### Phase 1 — "Card art & guardian scaling" (3/3 ✅)
- ✅ Six COMBO card icons: Combo Attack `7328c199…` / Combo Instinct `941c7381…` / Aether `d3dac5bf…` / High Aether `3c5ea7e3…` / Grave `bc4cf311…` / Marker `44651b98…` (32×32 skill sprites; registry probe, no dups; user saw the cards 08-17)
- ✅ Guardian HP scaling: `BossHPMult` column (25/28/32/38/45/25), `HuntingGroundLogic:GetBossHPMult()`, `SetBoss` = base × BossHPMult × min(3, 1 + 0.05×(level−1)); Chicken Farm Lv.1 = 500 → Fish Market Lv.20 = 1755 (user guardian fight 08-17 "all good")
- ✅ Acceptance 1–2 in-play (probes + user verdict 08-17 "all good, saved the world")
### Phase 2 — "Device pass & re-release" (5/5 ✅)
- ✅ On-device pass, both classes, PC + mobile — PC ✅ + mobile ✅, both classes, no findings (user 08-17)
- ✅ Fixes from the pass implemented + re-probed — F1–F3 (three under-sized tap targets: tracker toggle/tab, Inventory close, ItemTable close) fixed + probed 08-17; mobile pass confirmed no more
- ✅ Pre-release housekeeping: WeaponAether shell deleted by the user in Maker (08-17; disk residue `Global/WeaponAether.model` remains — Maker-managed dir, unreferenced, harmless); no unused template maps
- ✅ World Released by the user (08-17, after both passes); published world boots (user confirmed 08-17)
- ✅ Acceptance 3–5 in-play (user verdicts 08-17: mobile clean both classes, F1–F3 fixed, published build boots)

## 7. Data-driven
`BossHPMult` joins HuntingGroundData.csv (CSV is the source of truth; default 25 keeps today's balance). Player-power factor `k` is a single number in `MonsterController` (or `GameLogic`) — promoted to data only if a later milestone needs per-ground curves (→ roadmap Backlog).

## 8. Decisions (this milestone)
| Item | Status |
|---|---|
| COMBO icon RUIDs | Decided (08-17): Combo Attack / Combo Instinct / Aether / High Aether / Grave / Marker (Adele + Hero packs) — user may still override |
| Player-power factor k | Decided (08-17): k = 0.05/level above 1, cap ×3 (`MonsterController.bossPowerFactor`) — re-tune only if the user's guardian fight says so |
| Which template maps / dormant models to delete before release (`Models/Weapons/WeaponAether.model` shell) | Pending → Phase 2 (ask the user; never delete unconfirmed) |
| Acceptance checks | 1 six COMBO cards show distinct art · 2 guardian HP scales by ground + level w/ bar/phases intact · 3 both classes playable on mobile (all slots tappable, bar hidden until run) · 4 device-pass findings fixed · 5 published world boots and dates after 08-15 18:17 |

> ⚠️ Nothing beyond this milestone lives here — market/orders depth, tournament phases, further classes → `Docs/FloatingMarket-Roadmap.md`.

## 9. Plan changes (revision log)
| When | Type | What changed | Reason | Impact |
|---|---|---|---|---|
| 2026-08-17 | Add | Phase 2 fix items F1–F3 (tracker toggle/tab, Inventory close, ItemTable close enlarged for mobile touch targets) | AI static pre-check (all buttons < 88 px across `ui/*.ui`) ahead of the user's mobile pass | Fixes item 🟡 (built + probed; user mobile tap check pending) |
