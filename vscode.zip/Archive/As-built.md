# MapleStory Thailand: Floating Market — As-built log

> Running record of the world's implementation. Survives across milestones. ⚠️confirm = survey guess to verify with the user.
> This project predates the planning toolkit — everything below was built and verified in-play across July 2026 sessions (detailed history in `C:\Users\User\.claude\projects\C--Users-User-Rougelike\memory\floating-market-concept.md`).

## Current state (by system)
| System | Built | Where (key files) | Notes / gotchas |
|---|---|---|---|
| Core game flow (Title→Lobby→run→return) | @Logic + maps | `02. Logic/GameLogic`, `PlayerSetupLogic`, `map/Title|Lobby|InGame.map` | Lobby=MapleTile side-view, InGame=RectTile top-down survivors arena |
| Expedition loop (quota→boss→boat→delivery) | @Logic/@Component | `11. Expedition/`, `05. Monster/`, `06. ObjectPool/` | Pooled client-local monsters; server RPCs must live on Logics |
| Hunting grounds ×6 (data-driven reskins) | dataset + @Logic | `13. HuntingGround/`, HuntingGroundData.csv | Ground 6 = Endless Voyage |
| Level-up: EXP→choose-1-of-3→reroll | @Logic + .ui | `02. Logic/LevelUpLogic`, `01. UI/LevelUpUIController|SlotController`, `ui/LevelUpUI.ui` | 3 rerolls/run; batched picks; card intro anim; LevelUpData.csv max Lv 20 |
| Adele combat line (skill_aether, 4 stages) | @Logic + weapon | `04. Weapon/AetherSkillLogic`, `Weapon_Sword` | Plain→Punto→Cross→Divide; per-stage anim/sound/reach/hits; runs start at Plain |
| Adele summon line (skill_order, 4 stages) | @Logic ×4 | `04. Weapon/OrderSkillLogic|GatheringSkillLogic|BlossomSkillLogic|CreationSkillLogic`, `OrderSwordComponent` | ORDER→GATHERING→BLOSSOM→CREATION, one level-up card per stage; CREATION = passive proc on swings |
| Class ultimate (skill_signature) | @Logic | `16. Signature/SignatureSkillLogic` | Level-up card since 07-28; combo 20 arms, Q casts; violet badge |
| Card type badges | .ui + controller | `01. UI/LevelUpSlotController`, `ui/LevelUpUI.ui` TypeBadge | Combat=red, Summon=orange, Ultimate=violet; square 3px border |
| Meta progression (coins/food/legacy/rep/market) | @Logic + datasets | `12. FoodShop/`, `18. Legacy/`, `15. Order/`, `19. Market/`, `DataStorageLogic` | Coins cap 999999; per-user DataStorage keys |
| Endless mode + leaderboards + daily trial | @Logic | `17. Endless/`, `20. Tournament/` | Seeded LCG streams; offers consume the tournament stream (RollOffer) |
| Run summary (voyage stats + bonus coins) | @Logic + .ui | `21. Summary/RunSummaryLogic`, `ui/RunSummaryUI.ui` | Bonuses pay real coins, ≤200 server clamp |
| HUD (skill bar, trackers, joystick) | .ui + controllers | `ui/InGameUI.ui`, `01. UI/SkillBarUIController` etc. | Slots gate on each skill's own unlock; key labels PC-only |

## Standing issues & handoff rules   (update in place — never re-append)
| Issue / rule | Workaround / rule | Count | First → last seen |
|---|---|---|---|
| UIBuilder strict-lint failure DELETES the target .ui | Backup to scratchpad before every risky write; recover from `Rougelike Test.mod` if lost | 1 | 07-27 → 07-27 |
| Maker re-stringifies InGameUI legacy Font fields | patchComponent Font:1 on both bars' HPText before every InGameUI.ui write | many | 07-22 → 07-28 |
| Live Maker dataset can diverge from workspace CSV | After CSV edits, verify via `_DataService:GetTable` probe in play | 2 | 07-27 → 07-28 |
| maker_execute_script runs CLIENT context only | ServerOnly methods silently no-op from probes; reach them via a temporary @Server RPC (senderUserId) | 1 | 07-28 → 07-28 |
| User type as property in new @Logic → LEA-3030 | Store plain values (e.g. number) instead of user @Struct types in new Logics | 1 | 07-28 → 07-28 |
| Maker version upgrade (26.5→26.7) migration STRIPPED every `script.*` component from all .ui files + Lobby.map, re-typed Font fields to string, AND post-migration refreshes DELETED 41 unregistered .mlua+.codeblock files (whole feature folders) | .ui/map comps: restore from `Rougelike Test.mod` (restore_script_comps.cjs). Scripts: replay Write/Edit history from ALL session transcripts (recover_all_sessions.py), then verify/patch against the mod's embedded codeblock JSON (verify_against_mod.py — the mod embeds FULL source per method and is authoritative for hand-edits). Never patch Font:1 anymore (U006 requires string). Keep the .mod + scratchpad workspace-backup until the world is re-published | 1 | 08-11 → 08-11 |
| 26.7 preserves model child hierarchy where 26.5 flattened it | Runtime-spawned model child lookups must use GetChildByName(name, true) (recursive); non-recursive lookups that worked pre-26.7 silently nil | 1 | 08-11 → 08-11 |
| 26.7 Maker imports/removes SCRIPT REGISTRATIONS only at app startup — in-session refresh_workspace never registers new scripts, never unregisters deleted ones, and (after a save) may stop ingesting even content edits | Plan every registration change (new/deleted/renamed .mlua) around a Maker restart; verify with a runtime marker probe before trusting any refresh; never save in Maker while edits are un-verified | 4 | 08-11 → 08-11 |
| ROOT-CAUSE RULE (Count≥3 escalation): an in-Maker manual save while AI file edits are pending forks Maker's script DB — on the next restart it imports the disk files as `<Name>_Automated_Changed_0` DUPLICATES (both copies run; logics execute twice) while canonical names keep the stale saved code. Re-pointing disk .codeblock ids does NOT heal it | PROCEDURE: never save in Maker while AI edits are un-ingested (verify a marker in play first). If forked: user deletes all `*_Automated_Changed_0` entries in Maker's workspace panel, restarts Maker, then refresh + marker probe | 1 | 08-11 → 08-11 |
| TRUE ROOT CAUSE of the whole refresh-no-op/fork saga (found 08-12): 26.7 LocalWorkspace ingests .mlua content edits ONLY via the **Local Changes → Check In** dialog (user clicks All → Check In). refresh_workspace alone never writes content into the script DB; startup import forks `_Automated_Changed_0` instead of updating; Maker actively re-serializes DB→disk over AI edits (own codeblock ids + deep indent); the LocalWorkspace toggle can be OFF after a Maker restart (refresh returns "Local workspace feature is not active") | After every .mlua batch: refresh → user opens Local Changes, refreshes the list, All → Check In → marker probe in play → only then save. Stage recovery/paste sources OUTSIDE RootDesk (`PasteMe/`, scratchpad) because Maker overwrites RootDesk copies. If runtime is stale but disk is correct, suspect a missed Check In first | 1 | 08-12 → 08-12 |

## Log
### 2026-08-11 Phase 1 complete (M1 Skill Evolution)
Data-driven skill registry shipped: SkillData.csv (8 rows: SkillID/Category/MaxLevel/PrerequisiteSkill/PrerequisiteLevel/Weight/SwordOnly) + `22. SkillTree/SkillTreeLogic` (live levels from owning logics, eligibility incl. data-driven prereq skill_order⇐skill_aether≥2, weight ×(1+0.15/category pick, cap 2×), build scores, run reset). LevelUpLogic: weighted sampling w/o replacement via tournament stream, no-repeat-triple guard. Cards: Passive(green)/Utility(blue) badges + stat "Lv.N > N+1" lines. Wiring: EnhancePlayer→OnPicked, StartExpedition→ResetForRun. Verified in-play: prereq flip at aether 2, 20 draws no dup/locked, 10 draws no identical repeat, tracking/reset, badge colors. Same session: recovered the 26.7-migration script-component wipe (see Standing issues) and fixed SelectCharacterSlotController for nested spawn hierarchy (recursive lookups + retry).

### 2026-07-28 Seed — surveyed on toolkit adoption (brownfield)
Fully working Thai Floating Market action-roguelite: 6 hunting grounds, Adele class with staged combat/summon/ultimate skill lines drawn from level-up cards, meta progression (food/legacy/orders/market levels), endless mode + daily tournament, voyage summary. All systems verified in-play at build time. Survey confirmed 3 maps + 78 scripts in 21 feature folders matching the memory record. ⚠️confirm: none — state cross-checked against the session's own memory file.
