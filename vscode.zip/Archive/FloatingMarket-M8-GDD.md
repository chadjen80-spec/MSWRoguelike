# Floating Market — Night Lord Kit (M8 GDD)

> 🔖 **AI note — resuming?** If you're reading this in a new session to continue/resume this game, load the `msw-planning` skill FIRST and follow its resume flow (read `FloatingMarket-Roadmap.md` + `Archive/As-built.md` → reconstruct state → reconcile) — don't edit or implement straight from this doc. **Before touching any `⬜/🟡/✅` state or running a completion, Read the skill's `references/build-management.md` IN FULL.**
> Last updated: 2026-08-25 / Stage: ✅ complete — all phases user-verified on device 08-25

## 1. One-line concept
> "The Thief becomes the Night Lord: a throwing-star build class where star volleys grow from Lucky Seven to Quadruple Throw, a Shadow Partner echoes every throw, Flash Jump darts through the swarm, and Assassin's Mark makes focused targets melt — with the same card-driven, class-gated build variety Adele and the Battle Mage already have."

## 2. Key decisions (immutable baseline)
| Item | Decision | Notes |
|---|---|---|
| Chassis | **IDs kept** (M4 recipe): `Character_Assassin`, `Weapon_Dart`, `UI_Assassin`, signature DOMINION — display names only become Night Lord | Class-select card keeps "Thief"; hero identity = "the Night Lord" (renamed 08-20 in `LegacyLogic`/`SkillTreeLogic`, done) |
| Skill lines | 4 new class-gated card lines, one @Logic each in `04. Weapon/` (M4 pattern): star combat, Shadow Partner, Flash Jump, Assassin's Mark | `RequiredWeapon=Weapon_Dart` rows; Adele/Battle Mage untouched |
| Star combat line | `skill_star` COMBAT, 4 stages: **Lucky Seven → Triple Throw → Quadruple Throw → Dark Flare** — N stars per volley toward LookDirectionX, per-star damage lines, stage 4 adds a lingering flare zone | `StaffSkillLogic` pattern (forward multi-hit, cadence per stage); rides `Weapon_Dart`'s swing like Aether rides the sword |
| Shadow Partner (authentic-spec rev 08-22) | `skill_shadow` companion, **single level**: one summon flash (`7fab246b…`, played once), then the shadow (`c4cb0ca6…`, looping, facing-flip re-attach) **mimics ALL the player's attacks at 70% of FINAL damage** — hook in `MonsterController.GetDamage` (the universal damage sink), `isEchoing` re-entrancy guard, 0.12 s mimic delay, echo shown as its own smaller damage line | User-picked RUIDs; covers stars, Dark Flare, FUMA lines, everything — echo rides post-mark/aura/vulnerability multipliers |
| Flash Jump | `skill_flash` UTILITY, 3 levels: dash 2.5/3/3.5u with 0.4s i-frame, cd 5/4/3s × CDR; key 1 / quick-slot tap | `TeleportSkillLogic` pattern reuse (same body/blink mechanics, thief visuals) |
| Assassin's Mark | `skill_mark` debuff, 3 levels: every 4th star hit on the same monster marks it — marked take **+15/20/25%** damage from all sources, mark visual on the monster | `isAuraDebuffed`-style flag on `MonsterController` (new `isMarked`); DamageCalcHelper hook |
| Signature: FUMA SHURIKEN (was DOMINION; authentic-spec rev 08-22) | Every attack strikes **up to 6 enemies for 615% × 7 lines**. The giant star **flies a set distance** (4.4 u over ~0.7 s, one attack per monster passed), then **holds the spot 2 s** (8 additional attacks @0.25 s in the r1.8 × enhance ring) before disappearing. **Recasting mid-flight anchors it on the spot** (free); a fresh cast is refused while it holds (one star) | User-picked RUIDs: effect `6214486b…`, hit `cd78f86b…`, icon `459228cf…`; trio row IDs (`dominionMastery`…) kept, display renamed FUMA |
| FUMA trio | 3 class-gated COMBO rows (mastery / enhance / final — ids `dominionMastery`/`enhancedDominion`/`finalDominion`) feeding `SignatureSkillLogic`'s class-agnostic hooks | Mirrors RUIN trio / GENESIS trio; unlocks after `skill_signature`; enhance scales the spin ring |
| Build titles | Dominant category: COMBAT "SHURIKEN MASTER" / SHADOW "SHADOW MASTER" / COMBO "FUMA MASTER"; freestyle "NIGHT FREESTYLER" | Replaces the hardcoded flat "NIGHT LORD" return in `SkillTreeLogic:GetBuildTitle` |
| HUD | SkillBar: cloned slots at the M4 positions (Shadow at ORDER pos, Flash at GATHERING pos, Mark at BLOSSOM pos — one class visible at a time); SkillUI quick slots join the class-shared branches (slot_01 + Flash Jump, slot_02 + Shadow Partner status) | Builder-native TextGUIRenderer labels only (TGR stub gotcha) |
| Verification | Class is fully AI-verifiable single-client (like M4): probes + scripted runs; on-device feel = user pass at the end | Duel/multiplayer untouched by this milestone |

## 3. Core loop (one session)
Pick Thief at the Boat Captain → runs start with bare darts → cards offer the class-gated Night Lord lines → build toward star-storm (COMBAT), shadow-echo (SHADOW), or DOMINION-combo — Flash Jump keeps you alive in the swarm, marks melt the guardian → run summary names the build (SHURIKEN/SHADOW/DOMINION MASTER) → same market meta as every class.

## 4. Core systems
- **StarSkillLogic** (`04. Weapon/`): stage 0 = plain dart (current behavior untouched); stages 1–4 replace `Weapon_Dart`'s throw with an N-star volley (2/3/4/4+flare) — per-stage anim/sound/star count/damage mult, per-star damage lines, cadence per stage; run-scoped, reset in `StartExpedition`.
- **ShadowSkillLogic**: looping shadow clip attached behind the player (offset mirror of the Death reaper), re-attached on facing flip; `EchoVolley(targets, mult)` called from the star line's damage site producing its own (dimmer) damage lines.
- **FlashJumpLogic**: `TeleportSkillLogic` mechanics with thief dash visuals/sound; key 1 + SkillUI slot_01 branch + SkillBar slot.
- **MarkSkillLogic**: per-monster star-hit counter; 4th hit sets `MonsterController.isMarked` + mark clip; `DamageCalcHelper` multiplies damage into marked targets; marks clear on death/pool reuse (`InitDefault`).
- **Class gating & cards**: `SkillData.csv` rows (`RequiredWeapon=Weapon_Dart`), `EnhanceData.csv` card rows + icons (msw-search, pack-first), `UIStringData.csv` entries, `LevelUpSlotController` card branches (badge colors reused: combat red, shadow indigo?, utility blue, combo teal).
- **Titles**: `SkillTreeLogic` thief title table + freestyle; summary build line lists star stage / shadow / flash / mark levels (`RunSummaryLogic`).

## 5. System ↔ MSW mapping
| Game system | MSW implementation |
|---|---|
| Star volley | `StarSkillLogic` @Logic (ClientOnly) + `Weapon_Dart.RequestAttack` reading `_StarSkillLogic.stage` live per throw (Aether-in-sword pattern); `OverlapBoxAll`/projectile sweep like the staff line |
| Shadow Partner | `ShadowSkillLogic` @Logic; `PlayEffectAttached(isLoop=true)` clone clip + `RemoveEffect` on reset (Death reaper pattern); echo damage via `MonsterController:GetDamage` |
| Flash Jump | `FlashJumpLogic` @Logic; `KinematicbodyComponent:SetWorldPosition`, `isInvulnerable` window, `GetEffectiveCooldown` |
| Assassin's Mark | `MonsterController.isMarked` flag + counter table in `MarkSkillLogic`; damage hook in `DamageCalcHelper` (aura-debuff pattern) |
| Cards & gating | `SkillData.csv` `RequiredWeapon` column (M4 mechanism), `SkillTreeLogic:IsEligible` unchanged |
| HUD slots | UIBuilder clones on `ui/InGameUI.ui` SkillBar (`SlotShadow`/`SlotFlash`/`SlotMark`), TGR labels; `SkillUIController` class-shared branches |
| Resources | msw-search pack-first: Night Lord / thief skill packs (star throw clips, shadow clone, flash jump, mark) — user-picked RUIDs win |

## 6. Roadmap (Phases)
### Phase 1 — "Star storm" (the class feels new) — ✅ complete (3/3 ✅, probe pass 08-22)
- ✅ `StarSkillLogic` + `Weapon_Dart` stage integration: Lucky Seven → Triple → Quadruple → Dark Flare volleys, per-stage anim/sound/cadence/damage, stage-aware bar icon — *verified in a scripted run: autonomous volleys `2★ / 3★×10 @~0.6 s / 4★×18`, Dark Flare hits 1–5 real monsters (Enable guard added — parked pool monsters were being hit), zero errors*
- ✅ Class gating: `SkillData.csv`/`EnhanceData.csv`/`UIStringData.csv` rows (`RequiredWeapon=Weapon_Dart`), card branches + icons, offers verified Adele/Mage-clean — *eligibility matrix probed both directions (star only on dart; aether/staff/aura never on dart); live datasets ingested (22 SkillData rows, 22 EnhanceData rows); real card-pick routing advanced stage 1→2; in-run offer showed thief-only pool + DOMINION*
- ✅ Probe pass: scripted thief run — stage progression, volley hit counts, other classes' offer pools untouched — *ran 08-22; gotcha: `RequestEnhancePlayer` takes the `EnhanceDataType` ROW, not a name string (string no-ops silently)*
### Phase 2 — "Shadow & flash" (mobility + companion) — ✅ complete (3/3 ✅, probe pass 08-22)
- ✅ `ShadowSkillLogic`: clone visual + echo damage (30/45/60%), card line, reset rules — *clone attaches on learn (`loopSerial` set, facing-flip re-attach), echo verified through the real damage path (victim 20 HP → dead from a 100-atk ×30% echo), real card pick advanced Lv.1, run-start reset in the `StartExpedition` chain*
- ✅ `FlashJumpLogic`: dash + i-frame + cooldown, key 1, SkillBar slot + SkillUI slot_01 branch — *dash −2.5 u exact at Lv.1, cooldown 4.85 s (base × CDR) running; key 1 + both slots share the Teleport pattern (`SlotTeleport`/`slot_01` are now class-shared instead of Phase 3's planned clones — §9)*
- ✅ Probe pass: echo lines, dash distance/i-frame, slot behaviors — *ran 08-22; bar `SlotAura`/`SlotTeleport` enabled in thief mode with shadow/flash icons; eligibility airtight both directions; 24 SkillData rows live*
### Phase 3 — "Mark, trio & titles" (build depth) — ✅ complete (4/4 ✅, user pass 08-25)
- ✅ `MarkSkillLogic` + `MonsterController.isMarked` + damage hook; mark visual; pool-reuse clears — *hook landed in `MonsterController.GetDamage` (not DamageCalcHelper — the aura-debuff precedent); probe: 4 star hits branded a snail, a 100-damage hit dealt exactly 115 (+15%), `starHitCount`/`isMarked` cleared in `InitDefault`; Mark of Assassin pack 4100011 visuals*
- ✅ DOMINION trio COMBO rows (mastery/enhance/final) + card art — *rows gated `skill_signature` + `Weapon_Dart` (verified: ineligible pre-signature, eligible after, never on other classes); real `dominionMastery` pick drove `GetMasteryLevel()=1`; comboCards texts added*
- ✅ Night Lord build titles + `RunSummaryLogic` build line; Mark rides the class-shared `SlotDeath` (reaper gauge ⇄ mark level) — *titles probed: SHURIKEN/SHADOW/DOMINION MASTER + NIGHT FREESTYLER; brand slot live with the mark icon; summary line adds Stars(stage)/Shadow/Flash/Mark*
- ✅ Acceptance: three visibly different thief builds (star-storm / shadow-echo / DOMINION-combo) in scripted runs ✅ by AI; **user on-device pass ⚠️ pending** (feel, sounds, card art, volley balance — stage-2+ stars cleared Chicken Farm's quota in ~20 s)

## 7. Data-driven
Stage/level tables live inline in each @Logic (M4 pattern — few values); card metadata in `SkillData.csv`/`EnhanceData.csv`/`UIStringData.csv`. No new CSV files.

## 8. Decisions (this milestone)
| Item | Status |
|---|---|
| Names: class card stays "Thief", identity "the Night Lord" (renamed from Night Walker 08-20 — done) | Decided |
| 4 lines exactly (star/shadow/flash/mark) + trio — no Dark Sight stealth (no aggro system to hide from) | Decided; stealth → Backlog if wanted |
| Shadow Partner echoes star volleys only (not signature) | Decided (tune after Phase 2 feel) |
| Mark stacks with aura debuff? | Thief has no aura; mark is the thief's own multiplier — independent flags |
| Acceptance | 1 stage progression 1→4 with distinct volleys · 2 class gating airtight (no thief rows on other classes and vice versa) · 3 echo % correct · 4 dash + i-frame verified · 5 mark math verified · 6 titles per dominant category · 7 user on-device pass |

> ⚠️ Nothing beyond this milestone lives here — stealth/Dark Sight, thief-specific duel polish → `Docs/FloatingMarket-Roadmap.md` Backlog.

## 9. Plan changes (revision log)
| When | Type | What changed | Reason | Impact |
|---|---|---|---|---|
| 2026-08-20 | Milestone open | Backlog "Third-class kit" promoted to M8; tournament depth slid to M9 candidate; Night Walker → Night Lord rename applied immediately (`LegacyLogic.heroName`, `SkillTreeLogic` title) | User: "Begin thief class, change Night Walker to Night Lord" | M7 stays `⏳ user-test pending` (independent); rename needs a Maker refresh to go live |
| 2026-08-22 | Modify | Shadow Partner and Flash Jump ride the CLASS-SHARED `SlotAura`/`SlotTeleport` bar slots and SkillUI `slot_01`/`slot_02` instead of Phase 3's planned `SlotShadow`/`SlotFlash` clones; Phase 3 keeps only a Mark-line slot decision | Consistent with the 08-20 class-shared quick-slot architecture; zero new UI entities to maintain | Phase 3 item reworded; no state resets |
| 2026-08-22 | Modify | Signature DOMINION → **FUMA SHURIKEN**: whole-field one-shot replaced by a thrown ancient star (travel hits → 2 s anchored spin, 8 half-damage tick sweeps, `CastFuma` in `SignatureSkillLogic`); all DOMINION display strings renamed (trio cards FUMA MASTERY/ENHANCED FUMA/FINAL FUMA, title FUMA MASTER, Legacy tree line); row/skill IDs unchanged | User request with hand-picked RUIDs (respect on later edits): effect `6214486bfe8b48de84cdeee3ec6b2a98`, hit `cd78f86bb3cb40ebb40ecfcfa8a0240f`, icon `459228cf9906473d91d0df063132f3dd` | Re-verified live 08-22 (travel anchor, 9 tick lines on a tanky target, 1680 total ≈ budget); Phase 3 ✅ items stand — mechanics re-probed, hooks unchanged |
| 2026-08-22 | Modify | Shadow Partner brought to the authentic spec: **mimics ALL attacks at 70% of final damage** (was: star-hit-only echo at 30/45/60%) — universal hook in `MonsterController.GetDamage` with `isEchoing` guard; single-level skill (`skill_shadow` MaxLevel 3→1); summon flash `7fab246b…` played once; clone clip → `c4cb0ca6…` (user-picked RUIDs) | User request (authentic Shadow Partner) | Verified live: 1000 direct → exactly 700 echo, no echo-of-echo, clone attached, summon logged once, zero errors. Old dart-site echo hook removed |
| 2026-08-22 | Modify | FUMA SHURIKEN brought to the authentic spec: **615% × 7 lines on up to 6 enemies per attack** (multiplier 6.15, `FumaAttackEvent`, Blade-tween 7-line damage columns); star **always flies the full 4.4 u** (real-time timer flight, one attack per monster passed — no auto-anchor on hit); **recast mid-flight anchors it on the spot** (free, `fumaState`/`fumaStopRequested`); fresh casts refused while it holds | User request (authentic MapleStory numbers) | Verified live: full flight −0.9→−5.3 exact, one travel event = 664 × 7 = 4648 on a tanky target, recast stop at x=−2.8 with no combo cost, hold 8 ticks then idle, zero errors. ⚠️ Damage is ~43× atk per attack (vs RUIN's 8× once) — balance review flagged for the on-device pass |
