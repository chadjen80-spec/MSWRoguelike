# Floating Market — Battle Mage Kit (M4 GDD)

> 🔖 **AI note — resuming?** If you're reading this in a new session to continue/resume this game, load the `msw-planning` skill FIRST and follow its resume flow (read `FloatingMarket-Roadmap.md` + `Archive/As-built.md` → reconstruct state → reconcile) — don't edit or implement straight from this doc. **Before touching any `⬜/🟡/✅` state or running a completion, Read the skill's `references/build-management.md` IN FULL.**
> Last updated: 2026-08-17 / Stage: ✅ COMPLETE — all 3 Phases ✅ (13/13 items), user-verified 08-17; archived

## 1. One-line concept
> "Give the Battle Mage a real kit on the same roguelite skeleton Adele has: a forward staff combo that grows Triple → Quad → Death → Finishing Blow, an aura line that turns her into a walking zone (Dark → Yellow → Blue → Debuff Aura), a Teleport blink with i-frames, a Death reaper summon that reaps on kill charges, and DARK GENESIS on top — class-gated cards, Battle Mage build titles, three viable Battle Mage builds, Adele untouched."

## 2. Key decisions (immutable baseline)
| Item | Decision | Notes |
|---|---|---|
| Camera/map mode | RectTile InGame / MapleTile Lobby — unchanged | Teleport = `Kinematicbody:SetWorldPosition` on RectTile |
| Base | EXTEND the M1–M3 skeleton: SkillData/EnhanceData rows + per-line `@Logic` w/ stage table + weapon component + skill-bar slots + LevelUp cards + `SkillTreeLogic` categories/titles | Same pattern as Aether/Order lines (As-built) |
| Class gating | Generalize `SwordOnly` → data column `RequiredWeapon` (Weapon_Sword / Weapon_Thunder / empty); `IsEligible(skill, weaponID)`; `SwordOnly=1` rows keep working as `Weapon_Sword` | Adele never sees Battle Mage cards and vice-versa; Thief unaffected |
| IDs kept | `Character_Mage`, `Weapon_Thunder` (script/model/data ids) stay; only display names change | Save/legacy compatibility (M3 decision) |
| Kit shape | 4 lines: **STAFF** combat (`skill_staff`, 4 stages) · **AURA** (`skill_aura`, 4 stages) · **TELEPORT** utility active (`skill_teleport`, 3 levels) · **DEATH** summon active (`skill_death`, 3 levels) + existing DARK GENESIS signature + COMBO tree | Death and Aura share the new **AURA** category ("dark arts") so builds split three ways: COMBAT (staff) / AURA (aura+death) / COMBO |
| Resources | Real Battle Mage skill packs (skill/3200·3210·3211·3212 img) for icons/effects/sounds; searched by me, no user RUIDs required | Death reaper model uses skill/3200 `summon/*` clips |
| Balance guardrail | Battle Mage DPS/survival tuned to Adele's guardian-clear pace (all three builds must clear the guardian like M2 acceptance 11) | Numbers live in stage tables, tuned in feel passes |

## 3. Core loop (one session, Battle Mage)
Pick Battle Mage → run a ground: staff combo mows the front, level-up cards offer STAFF / AURA / TELEPORT / DEATH / COMBO / stats (class-gated) → build a Battle Master (staff), an Aura Master (aura + reaper), or a Ruin Master (combo → DARK GENESIS) → Teleport out of trouble → guardian → boat → VOYAGE SUMMARY names the build.

## 4. Core systems
- **Staff combat line** (`StaffSkillLogic` + `Weapon_Thunder`): forward multi-hit staff sweep replacing the aura strike; stages Triple Blow (3 hits) → Quad Blow (4 hits, +reach) → Death Blow (5 hits, +dmg, dark burst) → Finishing Blow (6 hits, wide, +knock); per-stage anim/hit effect/sound/reach/hits/damage table; card `skill_staff` (COMBAT, RequiredWeapon=Weapon_Thunder, MaxLevel 4).
- **Aura line** (`AuraSkillLogic`): looping aura visual attached to the player + 0.5s tick; Dark Aura (+dmg%) → Yellow Aura (+move speed, +attack cadence) → Blue Aura (−dmg taken) → Debuff Aura (enemies in radius slowed + take +dmg); card `skill_aura` (AURA, MaxLevel 4).
- **Teleport** (`TeleportSkillLogic`): key + bar slot; blink 2.5u toward facing (clamped to map), 0.4s i-frames (PlayerStatController flag), cooldown 5s − CDR; levels: distance/cooldown; card `skill_teleport` (UTILITY, MaxLevel 3).
- **Death** (`DeathSkillLogic` + `DeathReaperComponent` on a spawned reaper model via SpawnHelperLogic): reaper hovers by the player; every N kills = one charge → reaper `attack1` sweep (radius, % atk); levels: N↓ / dmg↑ / extra reap; card `skill_death` (AURA, MaxLevel 3).
- **Cards/HUD/titles**: LevelUpSlotController gets AURA badge color + card text/icons for the 4 new skills; SkillBar gets Battle Mage slots (staff / aura / teleport / death) shown only for the class, gated on unlock, Q = DARK GENESIS; `SkillTreeLogic:GetBuildTitle()` for Battle Mage: COMBAT→BATTLE MASTER, AURA→AURA MASTER, COMBO→RUIN MASTER, else DARK FREESTYLER.
- **Legacy**: Dark Legacy row 5 "Dark Overflow" unchanged; nothing else.

## 5. System ↔ MSW mapping
| Game system | MSW implementation |
|---|---|
| Class gate | SkillData.csv `RequiredWeapon` column (additive) + `SkillTreeLogic.IsEligible(SkillID, WeaponID)` + `LevelUpLogic` passes `statCtrl.startWeaponID` |
| Staff line | `StaffSkillLogic` (@Logic, ClientOnly, stage table + RUIDs) driving `Weapon_Thunder.RequestAttack` (front box sized per stage, `LookDirectionX`) |
| Aura line | `AuraSkillLogic` (@Logic): `_EffectService:PlayEffectAttached` loop + `SetTimerRepeat` tick over `MonsterSpawnPool` children; stat mods via PlayerStatController fields; slow via `MonsterController.movementComponent.InputSpeed` factor |
| Teleport | `TeleportSkillLogic` (@Logic): KeyDownEvent on `_InputService` + bar tap; `Kinematicbody`/`MovementComponent:SetPosition`; i-frames flag in `PlayerStatController` damage intake |
| Death | `DeathSkillLogic` (@Logic) + `RootDesk/MyDesk/Models/Summons/DeathReaper.model` (sprite clips from skill/3200) + `DeathReaperComponent` (follows player, plays `attack1`) + SpawnHelperLogic map entry |
| Cards | EnhanceData.csv rows `skill_staff/skill_aura/skill_teleport/skill_death` (+ UIStringData descriptions), SkillData.csv rows (categories COMBAT/AURA/UTILITY/AURA) |
| HUD | `ui/InGameUI.ui` SkillBar new slots via UIBuilder + `SkillBarUIController` refresh methods |
| Titles | `SkillTreeLogic:GetBuildTitle()` class branch |

## 6. Roadmap (Phases)
### Phase 1 — "Staff & the gate" (4/4 ✅)
- ✅ Class gate generalization: SkillData `RequiredWeapon` column, `IsEligible(skill, weaponID)`, LevelUpLogic passes weapon id; Adele/Thief regression probe
- ✅ Staff combat line: `StaffSkillLogic` stage table (4 stages, RUIDs from skill packs) + `Weapon_Thunder` forward multi-hit combo w/ per-hit damage numbers, swing anim on the player; card `skill_staff` (data + card text/icon)
- ✅ Skill bar: staff slot for Battle Mage (stage icon + Lv badge); Q slot now clickable (ButtonComponent + handler) for every class
- ✅ Acceptance 1–2, 6, 10 in-play (probes 08-15/16 + user verdict 08-16 "all good"; world saved)
### Phase 2 — "Aura & Teleport" (4/4 ✅)
- ✅ Aura line: `AuraSkillLogic` (visual loop + tick + 4 stage effects incl. enemy slow), card `skill_aura`, AURA badge color
- ✅ Teleport: `TeleportSkillLogic` (key 1 + slot, blink 2.5/3/3.5u via Kinematicbody, 0.4s i-frames, cooldown 5/4.5/4s × CDR), card `skill_teleport`
- ✅ Skill bar: aura + teleport slots (cooldown fill), key label
- ✅ Acceptance 3–4, 7 in-play (probes 08-16 + user verdict "all good"; world saved)
### Phase 3 — "Death, titles & three builds" (5/5 ✅)
- ✅ Death reaper: `DeathSkillLogic` (looping attached reaper visual, kill charges → auto reap sweep w/ damage numbers + Death hit), card `skill_death`, `SlotDeath` bar slot (charge gauge)
- ✅ Battle Mage signature trio: `genesisMastery` / `enhancedGenesis` / `finalGenesis` (COMBO, RequiredWeapon=Weapon_Thunder) — SignatureSkillLogic reads class-agnostic mastery/enhance/final levels; cards + icons
- ✅ Battle Mage build titles (BATTLE / AURA / GENESIS MASTER, DARK FREESTYLER) + summary lines (aura stage / Teleport Lv / Death Lv)
- ✅ Balance pass: three Battle Mage builds (staff / aura+death / combo) clear the guardian (user run 08-17 "all good"); reset probe ✅
- ✅ Acceptance 5, 8–9, 11 in-play incl. run-reset of all four lines (probes 08-17 + user verdict "all good, saved the world")

## 7. Data-driven
SkillData.csv (+`RequiredWeapon`) and EnhanceData.csv own eligibility, categories, prerequisites, weights, card icons/descriptions; per-stage numbers/RUIDs live in each line's `@Logic` stage table (same convention as AetherSkillLogic/OrderSkillLogic). No class constants in UI code.

## 8. Decisions (this milestone)
| Item | Status |
|---|---|
| Teleport key | Pending → key audit in Phase 2 (candidate: E / Shift; must not collide with Q signature, ORDER/GATHERING/BLOSSOM keys, WASD) |
| Death charge rule | Pending → start "every 6 kills = 1 reap", tune in Phase 3 |
| Aura numbers | Pending → start Dark +10% dmg, Yellow +0.3 speed/−10% cadence, Blue −15% dmg taken, Debuff radius 2.5u slow 25% +15% dmg taken |
| Staff stage numbers | Pending → start hits 3/4/5/6, reach 1.6/1.9/2.1/2.5, dmg ×1.0/1.15/1.35/1.6, cadence from WeaponData CoolTime 1.2 → 1.0 at Finishing Blow |

## 9. Plan changes (revision log)
| When | Type | What changed | Reason | Impact |
|---|---|---|---|---|
| 2026-08-15 | Modify | RUIN trio (ruinMastery / enhancedRuin / finalRuin) is Adele-only (`RequiredWeapon=Weapon_Sword`); Battle Mage gets her own DARK GENESIS trio (genesisMastery / enhancedGenesis / finalGenesis) as a new Phase 3 item, wired to the same SignatureSkillLogic hooks | User feedback in the Phase 1 test (FINAL RUIN offered to Battle Mage) | Phase 3 checklist +1 item; COMBO build for Battle Mage = comboMastery/relentless until then |
| 2026-08-16 | Fix | Signature READY never armed when the threshold isn't divisible by 4 (Dark Overflow = 90 → pips capped at 88): reaching the threshold now always counts as the 4th pip. Q skill-bar slot had no ButtonComponent/handler → now clickable for all classes. Damage numbers added to the staff combo (per hit) and to every signature hit; DARK GENESIS plays a per-victim hit effect (`cf6b856a…`); staff swing anim attached to the player entity | Phase 1 user test findings | Fixes; no plan scope change |
| 2026-08-16 | Modify | Battle Mage COMBO build title = **GENESIS MASTER** (GDD said RUIN MASTER; RUIN is Adele's); Death reaper implemented as a looping attached visual companion instead of a spawned `.model` entity (no SpawnHelperLogic surface, no pool interaction) | Phase 3 planning | §4/§5 Death row + titles read accordingly; no scope change |

## Acceptance checks (11)
1. Staff combo hits only in front, 4 stages visibly different (anim/hits/reach), Finishing Blow feels like a finisher
2. Class gate: Adele never sees STAFF/AURA/TELEPORT/DEATH cards; Battle Mage never sees AETHER/ORDER; Thief unchanged
3. Aura ring visible; each stage's effect measurable (dmg%, speed, dmg taken, enemy slow)
4. Teleport blinks toward facing with i-frames and cooldown; unusable before its card
5. Death reaper spawns after its card, reaps on kill charges, despawns at run end
6. DARK GENESIS + COMBO tree unchanged (100 combo, READY, consume)
7. Skill bar shows Battle Mage slots only for Battle Mage, gated on unlock, with cooldown fills
8. Build title = played build (BATTLE / AURA / RUIN MASTER, DARK FREESTYLER)
9. Three Battle Mage builds each clear the guardian
10. Adele and Thief runs behave exactly as before (regression)
11. Run reset: all four lines + charges reset at run start; permanent state persists
