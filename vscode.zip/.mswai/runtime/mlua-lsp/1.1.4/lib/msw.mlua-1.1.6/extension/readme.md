# mLua for Visual Studio Code

The VS Code mLua extension provides rich language support for the mLua language.

### See guide for more info.
* [mLua guide](https://maplestoryworlds-creators.nexon.com/ko/docs?postId=1287)
* [mLua extension guide](https://maplestoryworlds-creators.nexon.com/ko/docs?postId=1209)

## Features
* Annotation
* Highlighting
* Completion
* Diagnostic
* Hover
* Inlay Hint
* Go to reference
* Go to definition
* Go to type definition
* Find all reference
* Rename
* Signature helper