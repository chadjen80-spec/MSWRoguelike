# 1.1.6
* Fix an issue where static functions were accessible using `:`.
* Fix an issue where the `targetUserId` parameter was shown for functions not in Client execution space.
* Fix an issue where type inference did not work for values resulting from arithmetic operations on certain types.
* Fix an issue where a type error was incorrectly shown when assigning a `ComponentRef` type variable.

# 1.1.5
* Add `InspectorButton` Attribute
* Fix a type error when assigning `FastVector3` to `Vector3`
* Fix a type error when assigning `FastVector2` to `Vector2`
* Fix a type error when assigning `FastColor` to `Color`

# 1.1.4
* Add completion support for struct types used as component property types.
* Fix errors occurring when using struct types as component property types.

# 1.1.3
* Fix a crash that occurred when writing certain code patterns

# 1.1.2
* Support `@ExecSpace` usage in `Struct`, `State`, `BTNode`, `Item` and `Event`
* Improve `mLua Light` Theme

# 1.1.1
* Fix an issue where activation was not working

# 1.1.0
* Add `clamp` and `sign` functions to the `math`
* Fix an issue where extending `Item` or `StateType` caused errors.
* Add an error when attempting to extend types marked with the `sealed` annotation.
* Fix an issue where renaming a file did not update the related code.
* Add mLua theme: `mLua Dark` and `mLua Light`
* Fix an issue where identical error messages were not displayed after the first occurrence.
* Add icons to indicate lines where execution space control occurs during function calls.
* Add support for code formatting.
* Improve coloring for table initializer expression.

# 1.0.1
* Fixed an issue where Completion suggestions were case-sensitive in certain situations.
* Removed the comma from the trigger characters in Commit Character Support.
* Fixed an intermittent issue where renaming a type name using the Rename function caused unexpected behavior.
* Added a feature to automatically update script content when renaming a file.

# 1.0.0
* Initial Preview Release.