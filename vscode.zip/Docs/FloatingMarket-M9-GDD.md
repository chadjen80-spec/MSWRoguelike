# Floating Market — Personal Market Decoration (M9 GDD)

> 🔖 **AI note — resuming?** If you're reading this in a new session to continue/resume this game, load the `msw-planning` skill FIRST and follow its resume flow (read `FloatingMarket-Roadmap.md` + `Archive/As-built.md` → reconstruct state → reconcile) — don't edit or implement straight from this doc. **Before touching any `⬜/🟡/✅` state or running a completion, Read the skill's `references/build-management.md` IN FULL.**
> Last updated: 2026-09-01 / Stage: Phase 3 — awaiting user tests (P1 ✅, P2 ✅, P3 built + probed; communal shared market rework built 09-01 — needs probe + two-player device pass; polish look/sound pending)
> (M7 Phase 2 and M8's on-device pass remain parked — independent of this milestone.)

## 1. One-line concept
> "The Lobby becomes MY Floating Market: slot-based decoration zones layered ON TOP of the existing market progression — earn trophies by playing, buy Thai-market decor with coins, equip a boat skin that arrives at the pier after every run — so two players at the same Market Level own visibly different markets, and every run makes yours more personal."

## 2. Key decisions (immutable baseline)
| Item | Decision | Notes |
|---|---|---|
| Where | The EXISTING Lobby map — no separate house map; decoration layers ON TOP of the permanent `MarketDeco_L*` progression dressing | Never touches fixed gameplay zones (NPCs, pier, spawn, portals, Pond interaction) — slots are pre-placed by design where nothing important sits |
| Placement model | **SLOT-BASED MVP** — pre-authored hidden sprite entities `DecoSlot_NN` in Lobby.map; "placing" = set the slot's `SpriteRUID` + enable (the proven `MarketDeco_L*`/reskin pattern) | No free placement, no runtime spawning, no collision, no scripts on decorations, ROTATE cut from MVP → all §23 performance rules hold by construction |
| MVP scope | **10 slots** across 4 zones (A Pond Restaurant Exterior ×3 · B Market Walkway ×3 · C Canal Edge ×2 · D Pier/Boat ×2), 4 categories (FURNITURE / NATURE / MARKET / TROPHY + BOAT skins), **~18 decorations** | Zones E (Community) / F (Achievement Display) fold into later Market-Level slots — roadmap |
| Data-driven | `DecorationData.csv`: `DecorationID,Name,Category,SpriteRUID,RequiredMarketLevel,AcquisitionType,Price,Rarity,AchievementID` — adding decor = adding a row | No decoration hard-coded in Lobby logic (§22) |
| Persistence | UserDataStorage keys `DecoOwned` (id csv), `DecoSlots` (`slotNN|decoId;…`), `BoatSkin` (id) — minimum identifiers only, batched writes, event-driven | OrderLogic pattern: server cache per user + targeted client sync |
| Acquisition | A) **Achievement trophies** (granted by play, never purchasable) · B) **Coin shop** (coin sink via `DataStorageLogic.SpendCoins`) · C) **Premium tab = display-only "Future Feature"** | Premium/trophy items are never destroyed by REMOVE — return to inventory. Zero combat power from any decoration (cosmetic only) |
| Slot gating | Existing `MarketLogic` levels gate slots: Lv1 → 4 slots (zone A+B), Lv2 → +2 (zone B/C), Lv3 → +2 (zone C/D), Lv4 → +2 (zone D) = 10 | Rides the established rep→level thresholds 0/2/5/9/14; locked slots invisible in edit mode |
| Boat skin | Special category: equipping sets the ReturnBoat's sprite when it arrives after a run — customization visible IN gameplay | Cosmetic sprite swap on the existing `ReturnBoatComponent` entity; basic/traditional/festival boats |
| Edit mode | Lobby button **DECORATE MARKET** → MARKET EDIT MODE: slots show `[+]` markers, tap slot → **MY MARKET** inventory (right panel, category tabs, owned/quantity cards) → preview on the slot → PLACE / REPLACE / REMOVE / SAVE / EXIT | Normal NPC interaction suppressed during edit; mobile-first tap flow |
| Thai identity | All decor art = Thai floating market (stalls, lotus, lanterns, boats, baskets, coconut/banana trees) via msw-search; user-picked RUIDs always win | §17 |
| Verification | Fully AI-verifiable single-client (probes: data, save/load round-trip, gating, shop math, trophy grants) + user on-device pass for feel/art | Acceptance list §24 mirrored in Phase 3 |

## 3. Core loop (one session)
Run → return boat (in YOUR boat skin) → deliver, coins + rep + maybe a trophy achievement pops → DECORATE MARKET → place the new trophy / buy a lantern with run coins → market level rises over sessions → new slots open → "MY Floating Market" grows with every voyage.

## 4. Core systems
- **DecorationLogic** (`@Logic`, `12. Decoration/` folder): loads `DecorationData.csv`; server-side per-user caches `serverOwned/serverSlots/serverBoatSkin` (+ load/persist batched like OrderLogic); Server RPCs `RequestDecoState`, `RequestPlace(slot, decoId)`, `RequestRemove(slot)`, `RequestBuy(decoId)` (SpendCoins), `RequestEquipBoat(decoId)`; targeted `SyncDecoState(ownedCsv, slotsCsv, boatSkin)`; validation server-side (owned? slot unlocked at market level? category legal for slot? trophy not purchasable).
- **DecoSlotsComponent** (`@Component` on Lobby root, MarketDressing pattern): on Lobby enter / sync, applies `slotsCsv` — per slot entity set `SpriteRUID` + `Enable`; slots empty ⇒ hidden. Zero per-frame work.
- **Market edit mode** (client): `MarketEditController` — DECORATE MARKET button (Lobby HUD), edit state (suppress NPC touch via existing UI-manage close-all + an editing flag), `[+]` marker sprites over unlocked empty slots, tap-slot routing.
- **MY MARKET UI** (`ui/MarketEditUI.ui` via UIBuilder, TGR-only): right panel with tabs ALL/FURNITURE/NATURE/MARKET/TROPHY/BOAT, decoration cards (icon, name, rarity tint, Owned/×n or price/lock line), preview-on-slot (temp sprite), PLACE/REPLACE/REMOVE/CANCEL context, SAVE/EXIT top bar.
- **Decoration Shop** (tab inside MY MARKET or the same panel's unowned cards): COIN items buyable in place (price + confirm), ACHIEVEMENT items show their criterion, PREMIUM items show "PREMIUM COSMETIC — Future Feature".
- **TrophyLogic hooks** (inside DecorationLogic; no new system): achievement grants on existing events — guardian kills per ground (ExpeditionLogic.OnBossDefeated), 100 combo (SignatureSkillLogic READY), endless wave 25/50 (EndlessLogic), per-class mastery = win a run with the class's final-stage line. Grant = add to `DecoOwned` + toast.
- **Boat skin**: `ReturnBoatComponent` (or its sprite child) reads `DecorationLogic.clientBoatSkin` when the boat is enabled for arrival → swap sprite; Lobby boat visuals untouched.

## 5. System ↔ MSW mapping
| Game system | MSW implementation |
|---|---|
| Slot entities | 10 hidden sprite entities in `map/Lobby.map` via MapBuilder (`DecoSlot_01..10`, MapleTile Y on the walkway footholds, MapLayer sorting like `MarketDeco_*`; `[+]` markers = one shared marker sprite RUID toggled in edit mode) |
| Definitions | `DecorationData.csv` + `.userdataset` (manual pair, `_DataService:GetTable`) |
| Persistence | UserDataStorage `DecoOwned`/`DecoSlots`/`BoatSkin` in one `BatchSetAsync` (OrderLogic pattern); caches dropped on `UserLeaveEvent` |
| Edit UI | `ui/MarketEditUI.ui` (UIBuilder; builder-native `text()` → TGR only — never legacy TextComponent on new entities) + controller with UUID bindings |
| Coin sink | `_DataStorageLogic:SpendCoins(price, userId)` server-side (per-user, already verified) |
| Trophy events | Client hooks in existing Logics → Server RPC grant → owned sync + toast |
| Art | msw-search pack-first for stall/lantern/lotus/boat/trophy sprites; static `sprite` RUIDs preferred (decorations must not animate-tick unless the clip warrants it) |

## 6. Roadmap (Phases)
### Phase 1 — "The slots" (place/replace/remove/save round-trip)
- ✅ Data + persistence: `DecorationData.csv` (21 rows incl. 3 boat skins, 5 trophies), `DecorationLogic` server caches + RPCs + validation + batched save/load; probe: place → full play-session restart → layout reloads from DataStorage
- ✅ Slot entities + apply: 10 `DecoSlot_NN` in Lobby.map (zones A–D), per-slot `DecoSlotComponent` applies on sync (renderer-toggle, entity stays enabled); market-level gating (4/6/8/10 slots at Lv1/2/3/4) incl. server-side locked-slot refusal
- ✅ Edit mode + MY MARKET UI: DECORATE MARKET button (Lobby-only), `[+]` markers, slot tap → inventory panel (tabs, owned cards with item images, pager) → tap card = PLACE/REPLACE; REMOVE on filled slots; tap-to-move + drag-to-move placed decor; SAVE commits / EXIT discards; NPC touch suppressed while editing — user-verified on device 09-01 (incl. the drag test)
- ✅ Probe pass: full acceptance flow single-client (place/replace/remove/save/reload round-trip, free-copy guard, locked-slot refusal at market Lv3 vs Lv4 slots, markers only on unlocked empty slots, placed deco persists outside edit mode)
### Phase 2 — "Earn & buy" (acquisition)
- ✅ Coin shop: MY MARKET now lists unowned cards after owned ones — COIN cards show "Nc — tap to buy" (two-tap confirm → `RequestBuy` → server market-level gate + `SpendCoins` → owned + toast; repurchase allowed for extra copies per §8); ACHIEVEMENT cards show their criterion; PREMIUM shows "Future Feature" — probe-verified 09-01 (real buy: 50959→50559c, card flipped to owned)
- ✅ Trophies: `ReportTrophyEvent` Server RPC + event→trophy map (guardian_chicken / endless_25 / mastery_adele·mage·thief); hooks in `ExpeditionLogic.OnBossDefeated` (ground 1 + final-stage class lines) and `EndlessLogic.BeginNextWave` (wave 25); grant engine + idempotency + persistence probe-verified; **user-verified 09-01** — the Chicken Farm trophy toast popped in a real on-device run (and the RPC path re-verified via the P3 arrival probe)
- ✅ Probe pass: buy math (rich: exact −400c; insufficient: refusal on empty wallet), grant idempotent, ownership survives cache drop + DataStorage reload. Not probe-testable: the buy level-gate (no Lv4 coin item exists at the user's Lv3; same code path as the verified slot gate)
### Phase 3 — "The boat & the pass" (visible payoff + acceptance)
- ✅ Boat skins: `RequestEquipBoat` Server RPC (owned+BOAT validated, "" unequips); BOAT-tab cards show "tap to equip"/"EQUIPPED", tap equips; `ExpeditionLogic.OnBossDefeated` swaps the ReturnBoat sprite to the equipped skin on arrival — probe-verified 09-01 (equip sync, unowned refusal, real arrival path: authored 331a9ef7 → equipped 09ac1607, persistence reload). This test also verified the `ReportTrophyEvent` client→server RPC end-to-end (real-user chicken trophy granted in the Maker env)
- 🟡 Polish: rarity text tints (Rare skyblue / Epic violet / Legendary gold), edit-mode enter/exit click sound (project UI SFX `972843e7…`), markers-only-on-unlocked (P1-verified) — code in; **look & sound need the user's eyes/ears**
- 🟡 Acceptance: AI probe suite complete across P1–P3 (place/move/drag/save/load, gating, buy math, trophies, boat) — **user's final on-device pass pending** (§24 feel/art/mobile taps)

## 7. Data-driven
Everything in `DecorationData.csv`; slot→zone mapping + unlock levels as a small inline table in `DecorationLogic` (10 values). No decoration knowledge in Lobby logic.

## 8. Decisions (this milestone)
| Item | Status |
|---|---|
| Slot-based only; free placement / rotate / seasonal / premium purchase / VISIT MARKET / profile board → Backlog | Decided (user brief §20/§18/§19 — future) |
| 10 slots / 4 zones / ~18 decorations for MVP (brief allows 8–12 / 15–20) | Decided |
| Trophy criteria (v1): per-ground guardian first-kill ×2, combo 100, endless wave 25 + 50, class mastery ×3 (final-stage run per class) | Decided — tune names/art in Phase 2 |
| Decoration inventory quantity: single-copy per decoration id (×1), except coin decor repurchasable when placed in multiple slots? → **one purchase = one placement**; buying again allowed for extra copies | Decided (quantity tracked as count) |
| Acceptance | §24 items 1–21 of the brief, verified by probes + the user's device |

> ⚠️ Beyond this milestone (roadmap Backlog): free placement, ROTATE, zones E/F as dedicated systems, seasonal sets (Songkran/Loy Krathong), real premium purchasing, VISIT MARKET social flow, MARKET OWNER profile board, animated premium decor.

## 9. Plan changes (revision log)
| When | Type | What changed | Reason | Impact |
|---|---|---|---|---|
| 2026-09-01 | Core decision | **Communal shared market (owned-slots rule)** replaces the per-player client-side view: the Lobby's 10 slots are ONE world-shared layout every player sees. Server keeps `{slot → {decoId, ownerUid}}` in world-level `GlobalDataStorage("MarketDeco")/SharedSlots`; changes broadcast to all clients (`Multicast SyncSharedSlotsAll`) and ride the join push. Placement: anyone places from THEIR items into EMPTY slots (first-come, first-served); only the placer can move/remove/replace their placements (`RequestApplySlots` now merges "my contribution" — other owners' slots are untouchable, conflicts are skipped with a toast). Free-count = owned − my placements in the shared layout. Boat skins stay personal. Old per-user `DecoSlots` storage is ignored → previously placed items return to each owner's inventory once | User: "Make market decoration object which set appear for other player can see too" — chose "Owned-slots rule" via selectable prompt | DecorationLogic slot layer rewritten (shared state + ownership merge), MarketEditController ownership-gates pick-up/REMOVE/place, DecoSlotComponent unchanged; acceptance now includes two-player shared visibility |
| 2026-08-25 | Milestone open | M9 = Personal Market Decoration (user's full design brief distilled; MVP = brief §20–21); tournament depth slides to M10 candidate; future features (§18/§19, free placement, seasonal, premium purchase) → roadmap Backlog | User request: competition-build decoration system on the existing Lobby | M7 P2 / M8 user-pass stay parked; no existing system rebuilt |
| 2026-09-01 | Add (P1 item 3) | MY MARKET card icons: each card row shows the decoration's sprite in a 72×72 image at the left (`Card_N/Icon` in MarketEditUI.ui; controller sets `ImageRUID = entry.spriteRUID` on refresh — probe-verified via `.DataId` readback). Drag-to-move: touching a placed decoration and dragging (past a 0.3u threshold) moves it under the finger via `ScreenTouchHold` + `_UILogic:ScreenToWorldPosition`; release snaps to the nearest unlocked EMPTY slot within 1.5u (preview) or returns it (toast, still picked up); joystick-drag protection (drag armed only while the pick-up press is held) — probe-verified 09-01 (follow, threshold, snap-drop, position restore, EXIT revert) | User reference (MapleStory My Home): item images + drag to move | Both stay within the slot model; item 3 remains 🟡 awaiting user re-test |
| 2026-08-26 | Add (P1 item 3) | Tap-to-move: in edit mode, tapping a PLACED decoration picks it up (dims to 55% + "Moving <name>" hint); tapping an empty `[+]` marker moves it there (preview — SAVE/EXIT rules apply); tapping another placed deco switches the pick-up. User asked for MapleStory-My-Home-style free placement — chose the slots+tap-to-move middle ground via selectable prompt; full free placement stays in the roadmap Backlog | User reference screenshot (MapleStory My Home) | Probe-verified 08-26 (pick-up/dim/hint, move, EXIT reverts move, SAVE persists move, source-switch tint reset); item 3 stays 🟡 awaiting user re-test |
| 2026-08-26 | Modify (P1 item 3) | SAVE/EXIT semantics: place/remove are now a LOCAL preview (`PreviewPlace`/`PreviewRemove`); SAVE commits the whole layout via `RequestApplySlots` (server re-validates ids/unlocks/owned counts, one batched persist); EXIT discards unsaved edits by re-syncing from the server | User's on-device test: expected EXIT to cancel, but every edit saved instantly | Probe-verified 08-26 (preview→EXIT reverts; preview→SAVE→EXIT persists; over-placement clamped); item 3 stays 🟡 awaiting the user's re-test |
