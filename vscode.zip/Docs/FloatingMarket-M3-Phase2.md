# Floating Market — Phase 2 detailed plan (Pond loop & visible market)
> 🔖 **AI note — resuming?** If you're reading this in a new session to continue the build, load the `msw-planning` skill FIRST and resume through it (read `Archive/As-built.md` + the GDD → reconstruct state) — don't treat this as plain implementation and start editing straight from this doc. **Before implementing tasks or updating any `⬜/🟡/✅` state, Read the skill's `references/build-management.md` IN FULL** (state rules · completion cleanups · revision flow).
> Parent doc: FloatingMarket-M3-GDD.md · This Phase's goal: TODAY'S MEAL panel with a build recommendation pre-run; the Pond order loop audited end-to-end; the market visibly grows richer per level; acceptance 5–6 pass.
> **Skills to reference (this Phase)**: msw-scripting (+verify-checklist), builder-protocol core + map (Lobby.map prop work — MapleTile: Y is foothold-based, clone existing props' Y). Check-In workflow after every batch.

## Status checklist
> States: ⬜ not started · 🟡 implemented (untested) · ✅ tested.

- 🟡 T1 TODAY'S MEAL: MapSelect prep line v2 — "TODAY'S MEAL: <foods w/ levels>" + "Recommended: X BUILD" from highest-level synergy food (GENERAL excluded; clamped levels)
- 🟡 T2 Market growth pass: +8 props cloned into Lobby.map (L2 +customer; L3 +table +customer; L4 +boat2 +lantern2; L5 +2 customers +boat3 — same sprites/foothold Y, X-shifted, some mirrored, start disabled for ApplyDressing)
- ✅ T3 Pond order loop audit (probe 08-15: order 1 accepted → completed w/ 8 Chicken → +120 coins ([DataStorage] 24943) → rep 3→4 → activeOrder cleared → NPC mood re-applied)
- ⬜ T4 Acceptance 5–6 in-play  ⚠️ needs user test: TODAY'S MEAL readability + market growth visible when leveling up

## Key facts (from reconcile)
- Dressing convention: Lobby children named `MarketDeco_L<n>_*` auto-enable at market level ≥ n (`MarketDressingComponent.ApplyDressing`, re-applied on Lobby entry). Existing: L2 ×2 (Counter, Stall), L3 ×2 (Cafe, Customer), L4 ×3 (Boat, Customer, Lantern), L5 ×3 (Garland1/2, Lantern). NPC mood balloons per level already ship.
- `MapSelectUIController.RefreshPrepLine` currently prints a one-line feast-buff list into `prepText` (multi-line capable TextComponent).
- Order loop verified end-to-end in prior milestones (OrderLogic Check/complete, rep → Legacy echo every 5, MarketLogic mood) — T3 is an audit with fresh evidence, not new code.
- FoodShopLogic food entries now carry `synergyBuild` (Phase 1) — the recommendation source.

## Risks / cautions
- Lobby is MapleTile: cloned props MUST keep the source entity's Y (foothold alignment); only shift X. Use MapBuilder read → inspect source → sprite() with same RUID/scale/sorting.
- New Lobby entities are map content (not scripts) — refresh should suffice, but run the Check-In flow anyway (it covers .map changes in Local Changes).
- Customer NPC clones: decorative sprites only — do NOT clone NpcInteraction/ChatBalloon components (avoid duplicate interactions).
