# Floating Market — Duel Room (M7 GDD)

> 🔖 **AI note — resuming?** If you're reading this in a new session to continue/resume this game, load the `msw-planning` skill FIRST and follow its resume flow (read `FloatingMarket-Roadmap.md` + `Archive/As-built.md` → reconstruct state → reconcile) — don't edit or implement straight from this doc. **Before touching any `⬜/🟡/✅` state or running a completion, Read the skill's `references/build-management.md` IN FULL.**
> Last updated: 2026-08-20 / Stage: Phase 1 ✅ complete (two-client duel user-verified 08-20) — Phase 2 upcoming

## 1. One-line concept
> "Two guardians race the same seeded Daily-Trial voyage side by side: challenge a player in the market, both drop into the arena at the same instant with the same seed, a live feed shows your rival's wave/score/status while you fight your own swarm, the server declares the winner, and duel wins are recorded and watchable from the Lobby."

## 2. Key decisions (immutable baseline)
| Item | Decision | Notes |
|---|---|---|
| Camera/map mode | unchanged — InGame RectTile arena, Lobby MapleTile | Duels run in the existing static `InGame` map (players already share it; monsters are client-local) |
| Duel model | **Synchronized seeded race, not a shared battlefield**: each duelist fights their own client-local pooled monsters (unchanged run code); a server `@Logic` synchronizes start, seed, live progress feed, and result | Server-authoritative monsters (true shared PvE/PvP) are out of scope → roadmap Backlog "shared-arena duel" |
| Fair play | Duels ride the tournament gates: seeded RNG streams (`TournamentLogic` `RollOffer/Spawn/Event`), no food/legacy buffs, wave cap 10, same score formula | Seed = per-duel hash (server-generated), not the daily seed |
| Matchmaking | Lobby **Duel Board** (new NPC or existing Leaderboard NPC tab): list players currently in the Lobby → Challenge → target gets an Accept/Decline popup → 5-second countdown → both teleport into the arena | Server keeps one duel record per pair: `{a, b, seed, state, scores, startedAt}` |
| Live feed | Each client reports `wave/score/alive` to the server every 1 s (Server RPC, no DataStorage); server relays to the rival (Client RPC) → **Rival HUD panel** in InGameUI (name · wave · score · status) | Also fed to spectators (Lobby Duel Board mini-scoreboard) |
| Result | Server decides when both finalized (death or wave-10 clear + boat): higher final score wins; leaving/disconnecting = forfeit; rewards: winner +150c, loser +50c, both `DuelRecord` (wins/losses) in DataStorage; leaderboard gains a **DUEL WINS** mode | No Hero Echoes from duels |
| Rival visibility | Rival avatar stays visible in the shared arena (already the case) — nametag/hue only; no attempt to render their monsters | Client-local monsters cannot be shown to others by design |
| Multi-client testing | AI verifies logic single-client via probes (fake rival feed); real two-client flows need the user's second client (Maker multi-play / second account) → those items end `🟡 needs user test` | Verification limits don't shrink scope |

## 3. Core loop (one session)
Lobby → Duel Board → challenge a player → accept → countdown → both in the arena on the same seed → fight your swarm while the Rival HUD shows their pace → both finish (death / wave-10 + boat) → server verdict, coins, record → back in the Lobby the board shows the result; others could watch the live scores from the board while it ran.

## 4. Core systems
- **DuelLogic** (`@Logic`, server-authoritative): `RequestChallenge(targetUserId)` → `NotifyChallenge` (Client RPC to target) → `RespondChallenge(accept)` → `StartDuel` (seed = hash of both ids + server time; `Multicast`/targeted `BeginDuel(seed, rivalName)` to both → clients `ArmDuel(seed)` and teleport into `/maps/InGame/SpawnLocation` after a 5 s countdown toast); `ReportProgress(wave, score, alive)` (Server, 1 s cadence, throttled server-side) → `SyncRival(...)` (Client to the other); `ReportFinal(score, completed)` → verdict when both in → `DuelResult(winner, myScore, rivalScore)` + rewards + record; leave/forfeit handling via `UserLeaveEvent` + map-change hook.
- **TournamentLogic** integration: `ArmDuel(seed)` = `ArmTournament` with an injected seed and `isDuel=true`; `FinalizeTournament` also calls `_DuelLogic:ReportFinal`; no daily-board submit while dueling (or submit too? decided: NO — duel scores don't touch the daily board).
- **Rival HUD** (`ui/InGameUI.ui` new `DuelPanel` via UIBuilder + `InGameUIController` fields): rival name, wave, score, status (RACING / DOWN / FINISHED), and a small "you vs them" delta line; hidden outside duels.
- **Duel Board UI** (`ui/DuelBoardUI.ui` + controller, opened from a Lobby NPC): tab 1 "Players here" (online-in-Lobby list with Challenge buttons), tab 2 "Live duels" (spectator mini-scoreboard: pair, waves, scores — fed by `DuelLogic` broadcast at 2 s cadence), tab 3 "Records" (my wins/losses/streak + top duelists from a `DuelBoard` SortableDataStorage keyed by wins).
- **Records**: `DuelRecord` per user in UserDataStorage (`wins,losses,streak`), `DuelBoard` SortableDataStorage (wins) → LeaderboardUI mode 3 "DUEL WINS".

## 5. System ↔ MSW mapping
| Game system | MSW implementation |
|---|---|
| Duel state machine + relays | `DuelLogic` @Logic — `@ExecSpace("Server")` requests with `senderUserId`, targeted `@ExecSpace("Client")` RPCs (userId last arg), `UserLeaveEvent` for forfeits; per-user throttling table for `ReportProgress` |
| Seeded race | existing `TournamentLogic` LCG streams (seed injection), tournament fair-play gates untouched |
| Rival HUD | `ui/InGameUI.ui` `DuelPanel` (UIBuilder; TextGUIRenderer labels — never legacy TextComponent on new entities) + `InGameUIController` setters called from `DuelLogic` client RPCs |
| Duel Board + spectator | `ui/DuelBoardUI.ui` (UIBuilder, 3 tabs — runtime-patterns §6 tab toggle) + `DuelBoardUIController`; Lobby NPC (`NpcDuelComponent`, TouchReceive) — new NPC entity in Lobby.map via MapBuilder or reuse npc-9 leaderboard tab |
| Records | UserDataStorage key `DuelRecord` (`w,l,s`, event-driven, batch with nothing else needed) + `SortableDataStorage("DuelBoard")` `IncreaseAndWait` on win; LeaderboardUI mode 3 |
| Rewards | `_DataStorageLogic:AddCoins` server-side (existing) |

## 6. Roadmap (Phases)
### Phase 1 — "The race" (smallest playable duel) — ✅ complete (7/7 ✅, user-verified 08-20)
- ✅ `DuelLogic`: challenge → accept/decline → seed + countdown → simultaneous arena entry; `TournamentLogic.ArmDuel(seed)`; forfeit on leave; single-client probe path (fake rival) for AI verification — *built (`23. Duel/DuelLogic.mlua`, `TournamentLogic.ArmDuel`); server state machine + seed determinism + cancel/forfeit path probed via `server_main`; the two-client arm/teleport needs the user's second client*
- ✅ Live feed + Rival HUD: `ReportProgress` (1 s) → `SyncRival`; `DuelPanel` in InGameUI (name/wave/score/status/delta); hidden outside duels — *built (`DuelHUDController`, `ui/InGameUI.ui` DuelPanel); fake-feed probe drove the panel; real rival feed needs two clients*
- ✅ Verdict + rewards: `ReportFinal` from `FinalizeTournament`; winner/loser toasts, +150c/+50c, `DuelRecord` persisted, no daily-board submit during duels — *built; verdict math / `DuelRecord` load-save / no-daily-submit probed single-client; the real settle popup on both clients needs the user test*
- ✅ Duel Board UI v1: Lobby NPC → "Players here" list + Challenge; Accept/Decline popup on the target — *built (`ui/DuelBoardUI.ui`, `DuelBoardUIController`, `NpcDuelComponent` on `DuelReferee` in Lobby.map); board/popup open-close probed; a real second player in the roster needs the user test*
- ✅ Multi-user correctness: `DataStorageLogic` coins + best score become per-user server caches with targeted client sync (was one world-wide `@Sync` number — a second player's earnings moved everyone's display); every existing caller keeps its API — *rewritten; server probe with a second user id (`probeA`) shows isolated caches (add/spend/persist across sessions) and the local client's coins/best untouched; targeted sync guarded for offline users; the second client's own display needs the user test*
- ✅ Rival swing mirror: during a duel each swing's visual (sword/staff clip + facing + scale) is relayed server-side onto the swinger's avatar on the rival's screen — attacks are client-local effects, so without this the rival just stood there while monsters died (user request 08-20) — *built (`DuelLogic.OnLocalSwing/RelaySwing/ShowRivalSwing`, hooks in `Weapon_Sword`/`Weapon_Thunder`); marshal + guards probed; the actual mirrored visual needs the two-client test*
- ✅ Acceptance 1–4: single-client probes (state machine, seed determinism, HUD updates from a fake feed, verdict math) ✅ by AI; **two-client duel end-to-end ⚠️ needs user test** (second client)
### Phase 2 — "Watch & record"
- ⬜ Spectator: Duel Board "Live duels" tab (2 s server broadcast of active duels) — anyone in the Lobby can watch scores tick
- ⬜ Records: "Records" tab (my W/L/streak, top duelists via `DuelBoard` sortable) + LeaderboardUI mode 3 "DUEL WINS"; rematch button after a duel
- ⬜ Polish: rival nametag hue in the arena, result banner, duel fireworks salute for the winner in the Lobby
- ⬜ Acceptance 5–7 (probes + user two-client test)

## 7. Data-driven
Rewards (150/50c), countdown (5 s), report cadence (1 s / 2 s) live as `DuelLogic` properties (few values). Records in DataStorage. No new CSV.

## 8. Decisions (this milestone)
| Item | Status |
|---|---|
| Duel = synchronized race in the shared static arena (no shared monsters, no instance room) | Decided — instance rooms only if two concurrent duels visibly interfere (revisit at Phase 2) |
| Duel scores excluded from the daily board | Decided |
| Rewards 150c / 50c, no echoes | Decided (tune after user duels) |
| Lobby entry: new Duel NPC vs. leaderboard NPC tab | Pending → Phase 1 (default: new NPC "Duel Referee" near the pier; reuse npc-9 only if Lobby.map placement proves risky) |
| Acceptance checks | 1 challenge/accept/decline + countdown puts both players in the arena on the same seed · 2 Rival HUD updates ≤ 1 s behind · 3 verdict correct incl. death/forfeit; coins + record persisted · 4 duel does not pollute daily board · 5 spectator tab shows a live duel · 6 records/leaderboard mode · 7 two-client end-to-end by the user |

> ⚠️ Nothing beyond this milestone lives here — shared-arena PvE/PvP duel, 4-player brackets, replay/ghost → `Docs/FloatingMarket-Roadmap.md` Backlog.

## 9. Plan changes (revision log)
| When | Type | What changed | Reason | Impact |
|---|---|---|---|---|
| 2026-08-17 | Add | Phase 1 item "Multi-user correctness: per-user coins/best score in `DataStorageLogic`" | Single-client probe of the duel verdict showed `AddCoins(150, A)` moving the LOCAL player's coin display — the Logic held one world-wide `@Sync` total; a two-player duel would corrupt both wallets | New ⬜ item in Phase 1 (built same day); no code removed; API unchanged for callers |
| 2026-08-20 | Add | Phase 1 item "Rival swing mirror" (was implicitly excluded by the §2 "rival avatar visible, nametag/hue only" decision) | User's first two-client duel: the rival avatar stood motionless while its monsters died — swing visuals are client-local effect clips, invisible to the other client; user asked for the rival's attack animation | New 🟡 item in Phase 1 (built same day: `DuelLogic` relay + hooks in both weapons); §2 rival-visibility row now includes mirrored swing FX (monsters still never shown) |
