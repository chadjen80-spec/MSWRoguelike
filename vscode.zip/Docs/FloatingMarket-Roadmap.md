# MapleStory Thailand: Floating Market — Milestone roadmap

> 🔖 Cross-milestone direction: vision · release criteria · one slot per milestone · Backlog.
> This is NOT a GDD — the active milestone's contract is its `-M<n>-GDD.md`. Updated only at controlled moments (see guide).
> Last updated: 2026-08-15

## Vision & release criteria
- Vision: a Thai floating-market action-roguelite where Adele-style skill builds grow run by run — collect ingredients in top-down hunting grounds, deliver them in a living market, and chase high scores in endless/tournament modes.
- Release criteria: the skill evolution system feels build-defining (visibly different Combat vs Aether runs); all core loops (expedition, delivery, meta progression, endless, daily trial) verified on device; no template residue.

## Milestones
| M | Theme (one line) | Status |
|---|---|---|
| M1 | Adele Roguelike Skill Evolution System (categories, data-driven prerequisites/weights, 6-stage combat + 5-stage summon lines, reroll rules, card UI, build tracking, run reset) — all 10 acceptance checks in-play | ✅ done (GDD: `Archive/FloatingMarket-M1-GDD.md`) |
| M2 | Combo→RUIN strategic resource (100-combo, banked READY, consumption), STORM active cast, 6-skill COMBO build branch, 3-phase guardian w/ combo-farm adds + vulnerability window, elite spend-or-save — all 11 checks incl. three-build viability | ✅ done (GDD: `Archive/FloatingMarket-M2-GDD.md`) |
| M3 | Sprint 3: Food × Build economy loop (multi-effect foods w/ combat hooks, ingredient-gated upgrades, TODAY'S MEAL, visible market growth, result-screen suite w/ build title + food synergy + next-run hook) → `FloatingMarket-M3-GDD.md` | 🔨 active (Phase 1/3 done) |

## Backlog (wanted, not yet slotted)
- 6th daily order row for River Fish — needs a 6th OrderBoard row (noted 07-06)
- Multi-monster rosters per ground (crab as second Fish Market spawn) (noted 07-06)
- Boss HP scaling with ground tier / player power (noted 07-04)
- Weekly + Legendary order tiers; festival BGM at Market Lv.5; celebration fireworks (noted 07-09)
- Tournament phases: duel/FFA rooms, brackets, spectator, replay/ghost, server-side score validation (noted 07-12)
- Build-score-driven run-result naming & analytics (spec §8 "use later"; tracking ships in M1)
