# MapleStory Thailand: Floating Market — Milestone roadmap

> 🔖 Cross-milestone direction: vision · release criteria · one slot per milestone · Backlog.
> This is NOT a GDD — the active milestone's contract is its `-M<n>-GDD.md`. Updated only at controlled moments (see guide).
> Last updated: 2026-08-17

## Vision & release criteria
- Vision: a Thai floating-market action-roguelite where Adele-style skill builds grow run by run — collect ingredients in top-down hunting grounds, deliver them in a living market, and chase high scores in endless/tournament modes.
- Release criteria: the skill evolution system feels build-defining (visibly different Combat vs Aether runs); all core loops (expedition, delivery, meta progression, endless, daily trial) verified on device; no template residue.

## Milestones
| M | Theme (one line) | Status |
|---|---|---|
| M1 | Adele Roguelike Skill Evolution System (categories, data-driven prerequisites/weights, 6-stage combat + 5-stage summon lines, reroll rules, card UI, build tracking, run reset) — all 10 acceptance checks in-play | ✅ done (GDD: `Archive/FloatingMarket-M1-GDD.md`) |
| M2 | Combo→RUIN strategic resource (100-combo, banked READY, consumption), STORM active cast, 6-skill COMBO build branch, 3-phase guardian w/ combo-farm adds + vulnerability window, elite spend-or-save — all 11 checks incl. three-build viability | ✅ done (GDD: `Archive/FloatingMarket-M2-GDD.md`) |
| M3 | Sprint 3: Food × Build economy loop (multi-effect foods w/ combat hooks, ingredient-gated upgrades, TODAY'S MEAL, visible market growth, result-screen suite w/ build title + food synergy + next-run hook) → `FloatingMarket-M3-GDD.md` | ✅ done (GDD: `Archive/FloatingMarket-M3-GDD.md`) |
| M4 | Battle Mage kit: staff combat line (Triple→Quad→Death→Finishing Blow), aura line (Dark→Yellow→Blue→Debuff), Teleport blink, Death reaper companion (kill-charge reaps), DARK GENESIS trio, class-gated cards (`RequiredWeapon`), Battle Mage build titles — three viable Battle Mage builds, Adele/Thief untouched | ✅ done (GDD: `Archive/FloatingMarket-M4-GDD.md`) |
| M5 | Release polish & re-release: real icons for the six COMBO cards, guardian HP scaling by ground tier × player power (`BossHPMult` data), on-device pass on both classes + fixes, world re-release replacing the 08-15 pre-Battle-Mage build | ✅ done (GDD: `Archive/FloatingMarket-M5-GDD.md`; released 08-17) |
| M6 | Market & orders depth: 6th daily order row (River Fish), Weekly + Legendary order tiers (ISO-week / once-ever, board pages), festival BGM at Market Lv.5, celebration fireworks, second monster on two grounds (crab / octopus) | ✅ done (GDD: `Archive/FloatingMarket-M6-GDD.md`) |
| M7 | Duel Room: synchronized seeded race between two players (challenge from a Lobby Duel Board, same seed + countdown, live rival HUD feed, server verdict + rewards + duel records, spectator scoreboard, DUEL WINS leaderboard) → `FloatingMarket-M7-GDD.md` | 🔨 active |
| M8 | Tournament depth on top of the duel core: 4-player bracket lite, weekly championship board, ghost-rival pace line, server-side score plausibility validation | candidate |

## Backlog (wanted, not yet slotted)
- Shared-arena duel / co-op (server-authoritative monsters so both players fight the SAME swarm; true PvP or FFA rooms, real spectator camera) — a rewrite of the client-local run; only after M7's race model proves the demand (noted 08-17)
- Replay/ghost of a full run (no input-capture API — would need position/event logging) (noted 08-17)
- Third-class kit (Thief / Night Walker) on the M4 recipe: `RequiredWeapon`-gated rows, per-line @Logic in `04. Weapon/`, cloned bar slots, class titles (noted 08-17)
- Per-ground guardian curves (player-power factor k as data) — only if M5's single k proves insufficient (noted 08-17)
- Build-score-driven run-result analytics (naming shipped in M3/M4 titles; analytics/telemetry still open) (noted 07-xx)
