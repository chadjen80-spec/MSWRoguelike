# Floating Market — Phase 2 detailed plan (Line extensions & build identity)
> 🔖 **AI note — resuming?** If you're reading this in a new session to continue the build, load the `msw-planning` skill FIRST and resume through it (read `Archive/As-built.md` + the GDD → reconstruct state) — don't treat this as plain implementation and start editing straight from this doc. **Before implementing tasks or updating any `⬜/🟡/✅` state, Read the skill's `references/build-management.md` IN FULL.**
> Parent doc: FloatingMarket-M1-GDD.md · This Phase's goal: both build paths reach the sprint's chain lengths with visible behavior changes; cards state their upgrade effects; the run summary names the build; all 10 acceptance checks pass.
> **Skills to reference (this Phase)**: msw-scripting (+verify-checklist), msw-combat-system concepts already in context via existing weapon code.

## Status checklist
> States: ⬜ not started · 🟡 implemented (untested) · ✅ tested.

- 🟡 T1 Combat line → 6 stages (Cross II: +1 hit line +0.2 reach; Enhanced Divide: rear sword wave)
- 🟡 T2 Summon line → 5 stages (STORM: maxBlades 8, duration 16)
- 🟡 T3 Upgrade-effect lines on skill cards (combat/summon/ultimate)
- 🟡 T4 Build scores on voyage summary build line
- 🟡 T5 Acceptance test — 8/10 checks PASSED in-play on 2026-08-11 ([Acc2] evidence: popup+3 cards, immediate apply, prereq flip, maxed exit, rerolls 3>2>1>0>0, no dup, no identical repeat, run reset, build tracking); the new-stage checks (Cross II/Enhanced Divide swings, STORM 8 blades, updated card texts) are BLOCKED — see blocker below

## Blocker (2026-08-11, third Maker-state failure — duplicate script entries)
> The user's in-Maker save + restart made Maker import the 41 recovered scripts' disk files as **duplicate entries named `<Name>_Automated_Changed_0`** (these hold the NEW code) while the canonical names still run the OLD pre-save code — both copies boot (logics run twice: FoodShop/Order/HuntingGround duplicated). AI-side fixes tried and failed: refresh×N, re-pointing the on-disk .codeblock identity files at the original ids (registry ignores it). Disk state is 100% correct (all 77 scripts verified; SkillData.csv ingested — registry max 6). CSV ingestion works; only the script DB is split.
> UPDATE 2026-08-11 02:10: the dup deletion did NOT hold — the stale canonical entries are baked into the SAVED WORLD, and every Maker boot re-imports the disk files as fresh `_Automated_Changed_0` duplicates. FINAL PROCEDURE (in flight): the 41 broken scripts occupy exactly these 17 workspace folders — 04. Weapon, 05. Monster, 06. ObjectPool, 07. EXPItem, 08. Event, 09. ETC, 10. DropItem, 12. FoodShop, 13. HuntingGround, 14. RandomEvent, 15. Order, 16. Signature, 17. Endless, 18. Legacy, 19. Market, 20. Tournament, 21. Summary — and NONE of the 36 healthy scripts do (healthy = 01. UI, 02. Logic, 03. PlayerComponent, 11. Expedition, 22. SkillTree). ATTEMPT 2 FAILED (02:12 boot runs identical canonical AND dup ids as before the deletion — the world content did not change; the folder deletion did not remove script registrations, or the save did not commit). REVISED CHECKPOINTED PROCEDURE: (1) user deletes the stale scripts + `_Automated_Changed_0` twins in Maker's Workspace/script panel and KEEPS MAKER OPEN, does NOT save; (2) AI verifies in-session via probe (`_FoodShopLogic == nil` and dup == nil) — only if the deletion demonstrably took effect: (3) user saves, closes; (4) AI restores the 41 .mlua from `scratchpad/restore-stage`; (5) reopen → boot imports fresh → marker probe → Acc3 → T5. Fallback if deletion still doesn't stick: build the world fresh — create a new world in Maker and copy this workspace's files in (disk is a complete, correct copy of the game); or escalate to the MSW community/Discord for the DB-repair procedure.

## Task detail

### T1 Combat line 6 stages
- **Goal**: AetherSkillLogic maxStage=6, stageNames {Plain,Punto,Cross,Cross II,Divide,Enhanced Divide}, icons extended (Cross II reuses Cross art, Enhanced Divide reuses Divide art); Weapon_Sword.stageConfig: [4]=Cross II (hits 5, r+1.0, x1.5, Cross art), [5]=old Divide config, [6]=Enhanced Divide (Divide values, x1.75) + rear-wave branch in RequestAttack (stage≥6 also sweeps a rear box, hits 3).
- **Done**: swing logs at stages 4/5/6; stage-6 log shows rear sweep count; card at stage 3 offers Cross II, at 5 offers Enhanced Divide.

### T2 STORM
- **Goal**: OrderSkillLogic GetSummonStage 0–5, OnPicked 5th branch (stormLearned → maxBlades=8, duration=16), ResetForRun restores 6/12; card texts "/ 5".
- **Done**: probe — after STORM, 4 ORDER presses reach 8 blades; duration reads 16; card leaves pool at stage 5.

### T3 Card effect lines
- **Goal**: skill cards append explicit upgrade-effect lines (e.g. Cross II: "Hit +1 / Reach +0.2"); source = stage-effect strings next to the stage tables.
- **Done**: card text probes per stage.

### T4 Summary build line
- **Goal**: RunSummaryLogic build text appends "Build: Combat N · Aether N · Passive N · Utility N · Ultimate N" from SkillTreeLogic.
- **Done**: summary probe after a scripted run with known picks.

### T5 Acceptance (sprint §10)
1 level-up opens 3 valid cards · 2 selection applies immediately · 3 prerequisites enforced · 4 locked skills never appear · 5 maxed skills stop appearing · 6 reroll exactly 3/run, disabled at 0 · 7 no duplicate cards · 8 reroll avoids identical triple · 9 new run resets levels/rerolls/scores · 10 build scores tracked.
- **Done**: one scripted in-play pass logging evidence for each check.

## Risks / cautions
- Weapon_Sword stage table is user-tuned — extend, never reshuffle existing RUIDs.
- STORM must not break pooled-blade pair offsets (pairIndex formula already widens; verify 8 blades don't leash-snap).
- ORDER stacking presses: maxBlades change must flow through the full-flight refusal toast too.
